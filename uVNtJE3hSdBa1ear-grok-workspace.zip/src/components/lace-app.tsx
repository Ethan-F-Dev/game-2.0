import { useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { Pause, Volume2, VolumeX } from "lucide-react";
import { Engine } from "@/game/engine";
import type { HudSnap, Phase } from "@/game/types";

interface Save {
  v: number;
  best: number;
  mute: boolean;
  shake: boolean;
  volume: number;
}

function fmt(n: number) {
  return Math.max(0, Math.floor(n)).toLocaleString("en-US");
}

export function LaceApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const scoreRef = useRef<HTMLSpanElement>(null);
  const bestRef = useRef<HTMLSpanElement>(null);
  const comboRef = useRef<HTMLSpanElement>(null);
  const waveRef = useRef<HTMLParagraphElement>(null);
  const toastRef = useRef<HTMLParagraphElement>(null);
  const pulseRef = useRef<HTMLSpanElement>(null);
  const dashRef = useRef<HTMLSpanElement>(null);
  const pips = useRef<Array<HTMLSpanElement | null>>([]);
  const [phase, setPhase] = useState<Phase>("menu");
  const [save, setSave] = useState<Save>({ v: 1, best: 0, mute: false, shake: true, volume: 0.8 });
  const [touch, setTouch] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new Engine(canvas, {
      onPhase: setPhase,
      onSave: setSave,
      onFrame: (h: HudSnap) => {
        const score = fmt(h.score);
        if (scoreRef.current && scoreRef.current.textContent !== score) scoreRef.current.textContent = score;
        const best = fmt(h.best);
        if (bestRef.current && bestRef.current.textContent !== best) bestRef.current.textContent = best;
        if (comboRef.current) {
          const label = h.combo > 1 ? `x${h.combo}` : "";
          if (comboRef.current.textContent !== label) comboRef.current.textContent = label;
        }
        if (waveRef.current) {
          const label = `Wave ${h.wave}`;
          if (waveRef.current.textContent !== label) waveRef.current.textContent = label;
        }
        if (toastRef.current && toastRef.current.textContent !== h.toast) toastRef.current.textContent = h.toast;
        if (pulseRef.current) pulseRef.current.style.transform = `scaleX(${h.pulse})`;
        if (dashRef.current) dashRef.current.style.transform = `scaleX(${h.dash})`;
        for (let i = 0; i < 3; i++) {
          const pip = pips.current[i];
          if (!pip) continue;
          const on = i < h.hp;
          pip.dataset.on = on ? "1" : "0";
          pip.style.background = on ? (h.hp === 1 ? "var(--color-danger)" : "var(--color-glass)") : "var(--color-line)";
        }
      },
    });
    engineRef.current = engine;
    const syncTouch = () => {
      const coarse = window.matchMedia("(pointer: coarse)").matches;
      setTouch(coarse || window.innerWidth < 860);
    };
    syncTouch();
    window.addEventListener("resize", syncTouch);
    return () => {
      window.removeEventListener("resize", syncTouch);
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const playing = phase === "play" || phase === "pause" || phase === "dead";

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-ink text-glass">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        aria-label="Lace, a glass-wake skiff"
      />

      {phase === "play" || phase === "pause" ? (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-4 p-4 pt-[max(1rem,env(safe-area-inset-top))] sm:p-6">
          <div>
            <p className="text-xs tracking-widest text-subtle uppercase">Score</p>
            <p className="font-display text-3xl leading-none font-semibold tabular-nums">
              <span ref={scoreRef}>0</span>
            </p>
            <p className="mt-1 text-sm text-tide tabular-nums">
              <span ref={comboRef} />
            </p>
            <p ref={toastRef} className="mt-2 max-w-xs text-sm text-muted" />
          </div>
          <div className="text-right">
            <p ref={waveRef} className="font-display text-lg font-semibold">
              Wave 1
            </p>
            <p className="text-sm text-muted tabular-nums">
              Best <span ref={bestRef}>{fmt(save.best)}</span>
            </p>
            <div className="mt-3 flex items-center justify-end gap-1.5" aria-label="Hull">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  ref={(el) => {
                    pips.current[i] = el;
                  }}
                  className="h-2 w-7 rounded-full bg-glass"
                />
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {phase === "play" ? (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between gap-4 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:p-6">
          <div className="flex w-36 flex-col gap-2">
            <Meter label="Pulse" barRef={pulseRef} />
            <Meter label="Dash" barRef={dashRef} />
            <p className="hidden text-xs text-subtle sm:block">Space pulse · Shift dash</p>
          </div>
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-control border border-line bg-elev text-glass"
              aria-label={save.mute ? "Unmute" : "Mute"}
              onClick={() => engineRef.current?.toggleMute()}
            >
              {save.mute ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
            </button>
            <button
              type="button"
              className="flex size-11 items-center justify-center rounded-control border border-line bg-elev text-glass"
              aria-label="Pause"
              onClick={() => engineRef.current?.togglePause()}
            >
              <Pause className="size-5" />
            </button>
          </div>
        </div>
      ) : null}

      {phase === "play" && touch ? (
        <TouchLayer
          onStick={(x, y) => engineRef.current?.stick(x, y)}
          onDash={() => engineRef.current?.pressDash()}
          onPulse={() => engineRef.current?.pressPulse()}
        />
      ) : null}

      {phase === "menu" ? (
        <div className="absolute inset-0 z-20 flex items-end p-4 sm:items-center sm:p-10">
          <section className="rise max-h-[78dvh] w-full max-w-md overflow-auto rounded-panel border border-line bg-elev p-6 sm:p-8">
            <p className="text-xs tracking-widest text-subtle uppercase">Filament trial</p>
            <h1 className="font-display mt-2 text-5xl leading-none font-semibold tracking-tight">Lace</h1>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted">
              You weave a wake of glass. Fresh glass severs. Once it turns amber, it severs you.
            </p>
            <button
              id="start-run"
              type="button"
              className="mt-6 h-12 w-full rounded-control bg-glass text-base font-semibold text-ink transition-opacity duration-150 hover:opacity-90 active:opacity-80"
              onClick={() => engineRef.current?.startRun()}
            >
              Start run
            </button>
            <dl className="mt-6 grid gap-3 text-sm">
              <Row k="Helm" v="W thrusts, S brakes, A turns left, D turns right" />
              <Row k="Wake" v="Cross enemies with the trail you just drew" />
              <Row k="Dash" v="Shift slips through a hit, including your own amber" />
              <Row k="Pulse" v="Space, or a click, shatters the lace around you" />
            </dl>
            <Settings
              save={save}
              onVolume={(v) => engineRef.current?.setVolume(v)}
              onShake={(on) => engineRef.current?.setShake(on)}
              onMute={() => engineRef.current?.toggleMute()}
            />
            <p className="mt-4 text-sm text-subtle tabular-nums">Best {fmt(save.best)}</p>
          </section>
        </div>
      ) : null}

      {phase === "pause" ? (
        <Overlay title="Paused" detail="The wake is holding still.">
          <button
            type="button"
            className="h-12 w-full rounded-control bg-glass font-semibold text-ink"
            onClick={() => engineRef.current?.togglePause()}
          >
            Resume
          </button>
          <Settings
            save={save}
            onVolume={(v) => engineRef.current?.setVolume(v)}
            onShake={(on) => engineRef.current?.setShake(on)}
            onMute={() => engineRef.current?.toggleMute()}
          />
        </Overlay>
      ) : null}

      {phase === "dead" ? (
        <Overlay title="Wake closed" detail={`Score ${fmt(engineRef.current?.state.score ?? 0)}`}>
          <p className="text-sm text-muted tabular-nums">Best {fmt(save.best)}</p>
          <button
            type="button"
            className="mt-4 h-12 w-full rounded-control bg-glass font-semibold text-ink"
            onClick={() => engineRef.current?.startRun()}
          >
            Run again
          </button>
        </Overlay>
      ) : null}

      <span className="sr-only">{playing ? phase : "menu"}</span>
    </main>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="grid grid-cols-[4.5rem_1fr] gap-3 border-t border-line pt-3">
      <dt className="text-subtle">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}

function Meter({ label, barRef }: { label: string; barRef: RefObject<HTMLSpanElement | null> }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs text-subtle">
        <span>{label}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-line">
        <span ref={barRef} className="block h-full w-full origin-left bg-glass" style={{ transform: "scaleX(1)" }} />
      </div>
    </div>
  );
}

function Settings({
  save,
  onVolume,
  onShake,
  onMute,
}: {
  save: Save;
  onVolume: (v: number) => void;
  onShake: (on: boolean) => void;
  onMute: () => void;
}) {
  return (
    <div className="mt-5 flex flex-col gap-3 border-t border-line pt-4">
      <label className="flex items-center gap-3 text-sm text-muted">
        <span className="w-16">Volume</span>
        <input
          className="h-11 w-full"
          type="range"
          min={0}
          max={100}
          aria-label="Volume"
          value={Math.round(save.volume * 100)}
          onChange={(e) => onVolume(Number(e.target.value) / 100)}
        />
      </label>
      <div className="flex gap-2">
        <button
          type="button"
          className="h-11 flex-1 rounded-control border border-line text-sm"
          onClick={onMute}
        >
          {save.mute ? "Muted" : "Sound on"}
        </button>
        <button
          type="button"
          className="h-11 flex-1 rounded-control border border-line text-sm"
          onClick={() => onShake(!save.shake)}
        >
          {save.shake ? "Shake on" : "Shake off"}
        </button>
      </div>
    </div>
  );
}

function Overlay({ title, detail, children }: { title: string; detail: string; children: ReactNode }) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-ink/50 p-4">
      <section className="rise w-full max-w-sm rounded-panel border border-line bg-elev p-6 sm:p-8">
        <h2 className="font-display text-4xl font-semibold tracking-tight">{title}</h2>
        <p className="mt-2 text-sm text-muted">{detail}</p>
        <div className="mt-6">{children}</div>
      </section>
    </div>
  );
}

function TouchLayer({
  onStick,
  onDash,
  onPulse,
}: {
  onStick: (x: number, y: number) => void;
  onDash: () => void;
  onPulse: () => void;
}) {
  const knob = useRef<HTMLDivElement>(null);
  const active = useRef(-1);
  const origin = useRef({ x: 0, y: 0 });

  function place(dx: number, dy: number) {
    if (knob.current) knob.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
  }

  function release() {
    active.current = -1;
    place(0, 0);
    onStick(0, 0);
  }

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-28 z-20 flex items-end justify-between px-4">
      <div
        className="pointer-events-auto relative size-28 touch-none rounded-full border border-line bg-ink/80"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          active.current = e.pointerId;
          origin.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerMove={(e) => {
          if (active.current !== e.pointerId) return;
          let dx = e.clientX - origin.current.x;
          let dy = e.clientY - origin.current.y;
          const mag = Math.hypot(dx, dy);
          const max = 44;
          if (mag > max) {
            dx = (dx / mag) * max;
            dy = (dy / mag) * max;
          }
          place(dx, dy);
          const nx = dx / max;
          const ny = -dy / max;
          const m = Math.hypot(nx, ny);
          if (m < 0.2) onStick(0, 0);
          else {
            const scale = (m - 0.2) / 0.8 / m;
            onStick(nx * scale, ny * scale);
          }
        }}
        onPointerUp={release}
        onPointerCancel={release}
      >
        <div
          ref={knob}
          className="absolute top-1/2 left-1/2 size-11 rounded-full bg-glass"
          style={{ transform: "translate(-50%, -50%)" }}
        />
      </div>
      <div className="pointer-events-auto flex gap-3">
        <button
          type="button"
          className="size-14 rounded-full border border-line bg-ink/80 text-sm font-medium"
          onPointerDown={(e) => {
            e.preventDefault();
            onDash();
          }}
        >
          Dash
        </button>
        <button
          type="button"
          className="size-14 rounded-full bg-glass text-sm font-semibold text-ink"
          onPointerDown={(e) => {
            e.preventDefault();
            onPulse();
          }}
        >
          Pulse
        </button>
      </div>
    </div>
  );
}
