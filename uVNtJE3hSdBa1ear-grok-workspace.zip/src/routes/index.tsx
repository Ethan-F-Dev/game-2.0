import { createFileRoute } from "@tanstack/react-router";
import { LaceApp } from "@/components/lace-app";

export const Route = createFileRoute("/")({ component: LaceApp });
