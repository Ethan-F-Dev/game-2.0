import { AudioBus } from "./audio";
import { Input, type Sample } from "./input";
import { render } from "./render";
import { beginMenu, beginRun, createState, step } from "./sim";
import type { Effects, HudSnap, Phase, State } from "./types";
import { MAX_HP } from "./sim";

const STEP = 1 / 60;
const SAVE_KEY = "lace.v1";

interface Save {
  v: number;
  best: number;
  mute: boolean;
  shake: boolean;
  volume: number;
}

export interface EngineHooks {
  onPhase: (phase: Phase) => void;
  onSave: (save: Save) => void;
  onFrame: (hud: HudSnap) => void;
}

function loadSave(): Save {
  const blank: Save = { v: 1, best: 0, mute: false, shake: true, volume: 0.8 };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return blank;
    const p = JSON.parse(raw) as Partial<Save>;
    return {
      v: 1,
      best: typeof p.best === "number" ? p.best : 0,
      mute: !!p.mute,
      shake: p.shake !== false,
      volume: typeof p.volume === "number" ? p.volume : 0.8,
    };
  } catch {
    return blank;
  }
}

export class Engine {
  readonly state: State;
  private input: Input;
  private audio: AudioBus;
  private hooks: EngineHooks;
  private canvas: HTMLCanvasElement;
  private glow: HTMLCanvasElement;
  private viewCtx: CanvasRenderingContext2D;
  private glowCtx: CanvasRenderingContext2D;
  private raf = 0;
  private stopped = false;
  private last = 0;
  private acc = 0;
  private sample: Sample = { throttle: 0, steer: 0, pulse: false, dash: false, pause: false };
  private lastPhase: Phase = "menu";
  private ro: ResizeObserver | null = null;
  private shakeOn = true;
  private reduce: boolean;
  private save: Save;

  constructor(canvas: HTMLCanvasElement, hooks: EngineHooks) {
    this.canvas = canvas;
    this.hooks = hooks;
    this.state = createState();
    this.save = loadSave();
    this.state.best = this.save.best;
    this.shakeOn = this.save.shake;
    this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.state.reduce = this.reduce || !this.shakeOn;
    this.input = new Input();
    this.audio = new AudioBus();
    this.audio.muted = this.save.mute;
    this.audio.volume = this.save.volume;
    const view = canvas.getContext("2d", { alpha: false });
    if (!view) throw new Error("Canvas 2D is unavailable");
    this.viewCtx = view;
    this.glow = document.createElement("canvas");
    const glow = this.glow.getContext("2d", { alpha: true });
    if (!glow) throw new Error("Glow buffer is unavailable");
    this.glowCtx = glow;
    beginMenu(this.state);
    this.lastPhase = "menu";

    this.ro = new ResizeObserver(() => this.paint(0));
    this.ro.observe(canvas);

    const vis = () => {
      if (document.visibilityState === "visible") this.audio.resume();
    };
    document.addEventListener("visibilitychange", vis);
    this.onVis = vis;

    canvas.addEventListener("pointerdown", this.onPointer);

    window.__controlsTest = {
      getYaw: () => this.state.player.yaw,
      getSpeed: () => (this.state.phase === "play" ? this.state.player.speed : 0),
      setKeys: (codes) => this.input.setKeys(codes),
      setSteer: (v) => this.input.setSteer(v),
    };

    this.raf = requestAnimationFrame(this.loop);
    hooks.onSave(this.save);
  }

  private onVis = () => {};

  private onPointer = (e: PointerEvent) => {
    if (e.button !== 0) return;
    if (this.state.phase === "play") this.input.latchPulse();
  };

  destroy() {
    this.stopped = true;
    cancelAnimationFrame(this.raf);
    this.ro?.disconnect();
    this.input.destroy();
    this.audio.dispose();
    this.canvas.removeEventListener("pointerdown", this.onPointer);
    document.removeEventListener("visibilitychange", this.onVis);
    if (window.__controlsTest?.getYaw && window.__controlsTest.getYaw() === this.state.player.yaw) {
      delete window.__controlsTest;
    }
  }

  startRun() {
    this.audio.unlock();
    this.audio.startMusic();
    beginRun(this.state);
    this.state.reduce = this.reduce || !this.shakeOn;
    this.state.best = this.save.best;
    this.lastPhase = "play";
    this.hooks.onPhase("play");
  }

  togglePause() {
    if (this.state.phase === "play") this.state.phase = "pause";
    else if (this.state.phase === "pause") this.state.phase = "play";
    else return;
    this.lastPhase = this.state.phase;
    this.hooks.onPhase(this.state.phase);
  }

  toggleMute() {
    this.audio.unlock();
    this.save.mute = !this.save.mute;
    this.audio.setMuted(this.save.mute);
    this.persist();
    return this.save.mute;
  }

  setVolume(unit: number) {
    this.audio.unlock();
    this.save.volume = unit;
    this.audio.setVolume(unit);
    this.persist();
  }

  setShake(on: boolean) {
    this.shakeOn = on;
    this.save.shake = on;
    this.state.reduce = this.reduce || !on;
    this.persist();
  }

  stick(x: number, y: number) {
    this.input.setStick(x, y);
  }

  pressDash() {
    this.input.latchDash();
  }

  pressPulse() {
    this.input.latchPulse();
  }

  private persist() {
    if (this.state.best > this.save.best) this.save.best = this.state.best;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.save));
    } catch {
      /* private mode */
    }
    this.hooks.onSave(this.save);
  }

  private fx(): Effects {
    return {
      cut: () => this.audio.cut(),
      hit: () => this.audio.hit(),
      dash: () => this.audio.dash(),
      pulse: () => this.audio.pulse(),
      boom: () => this.audio.boom(),
      wave: () => this.audio.wave(),
    };
  }

  private loop = (now: number) => {
    if (this.stopped) return;
    const dt = this.last === 0 ? STEP : Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.sample = this.input.sample();
    if (this.sample.pause) this.togglePause();

    if (this.state.phase !== "pause") {
      this.acc += dt;
      let n = 0;
      const effects = this.fx();
      let first = true;
      while (this.acc >= STEP && n < 5) {
        const edge = first ? this.sample : { ...this.sample, pulse: false, dash: false, pause: false };
        step(this.state, edge, STEP, effects);
        first = false;
        this.acc -= STEP;
        n++;
      }
    } else {
      this.acc = 0;
    }

    if (this.state.phase === "dead" && this.state.best > this.save.best) {
      this.save.best = this.state.best;
      this.persist();
    } else if (this.state.best > this.save.best) {
      this.save.best = this.state.best;
    }

    if (this.state.phase !== this.lastPhase) {
      this.lastPhase = this.state.phase;
      this.hooks.onPhase(this.state.phase);
      if (this.state.phase === "dead") this.persist();
    }

    this.paint(dt);
    this.hooks.onFrame(this.hud());
    if (!this.stopped) this.raf = requestAnimationFrame(this.loop);
  };

  private hud(): HudSnap {
    const p = this.state.player;
    const s = this.state;
    return {
      phase: s.phase,
      score: s.score,
      best: Math.max(s.best, this.save.best),
      combo: s.combo,
      wave: s.wave,
      hp: p.hp,
      maxHp: MAX_HP,
      pulse: p.pulseCd <= 0 ? 1 : 1 - p.pulseCd / 3.25,
      dash: p.dashCd <= 0 ? 1 : 1 - p.dashCd / 1.15,
      toast: s.toastT > 0 ? s.toast : "",
      banner: s.bannerT > 0 ? s.banner : "",
    };
  }

  private paint(dt: number) {
    const canvas = this.canvas;
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    if (cssW < 2 || cssH < 2) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
    const pw = Math.max(1, Math.round(cssW * dpr));
    const ph = Math.max(1, Math.round(cssH * dpr));
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    if (this.glow.width !== pw || this.glow.height !== ph) {
      this.glow.width = pw;
      this.glow.height = ph;
    }
    this.state.frameDt = dt || STEP;
    this.state.reduce = this.reduce || !this.shakeOn;
    render(this.viewCtx, this.glowCtx, this.state, cssW, cssH, dpr);
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}
