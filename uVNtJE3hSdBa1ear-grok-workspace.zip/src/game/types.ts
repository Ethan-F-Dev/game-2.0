export type Phase = "menu" | "play" | "pause" | "dead";
export type Kind = "drift" | "lance" | "spit" | "split";
export type Hue = "tide" | "amber" | "danger" | "glass";

export interface Enemy {
  alive: boolean;
  kind: Kind;
  x: number;
  y: number;
  yaw: number;
  r: number;
  hp: number;
  maxHp: number;
  state: number;
  timer: number;
  cool: number;
  gen: number;
  flash: number;
  hurt: number;
  dx: number;
  dy: number;
  nearMiss: boolean;
  pulseSeen: number;
}

export interface Bolt {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
}

export interface Pt {
  x: number;
  y: number;
  age: number;
}

export interface Part {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  hue: Hue;
}

export interface Floater {
  alive: boolean;
  x: number;
  y: number;
  life: number;
  max: number;
  text: string;
}

export interface Player {
  x: number;
  y: number;
  yaw: number;
  speed: number;
  hp: number;
  iframe: number;
  flash: number;
  dashT: number;
  dashCd: number;
  pulseCd: number;
  radius: number;
}

export interface State {
  phase: Phase;
  t: number;
  player: Player;
  enemies: Enemy[];
  bolts: Bolt[];
  lace: Pt[];
  parts: Part[];
  floats: Floater[];
  laceX: number;
  laceY: number;
  laceInit: boolean;
  score: number;
  best: number;
  combo: number;
  comboT: number;
  wave: number;
  toSpawn: number;
  spawnT: number;
  rest: number;
  waveClear: boolean;
  banner: string;
  bannerT: number;
  toast: string;
  toastT: number;
  camX: number;
  camY: number;
  shakeX: number;
  shakeY: number;
  trauma: number;
  zoom: number;
  frameDt: number;
  hitstop: number;
  reduce: boolean;
  pulseId: number;
  pulseR: number;
  menuSpawn: number;
  moteT: number;
}

export interface FrameInput {
  throttle: number;
  steer: number;
  pulse: boolean;
  dash: boolean;
}

export interface Effects {
  cut: () => void;
  hit: () => void;
  dash: () => void;
  pulse: () => void;
  boom: () => void;
  wave: () => void;
}

export interface HudSnap {
  phase: Phase;
  score: number;
  best: number;
  combo: number;
  wave: number;
  hp: number;
  maxHp: number;
  pulse: number;
  dash: number;
  toast: string;
  banner: string;
}
