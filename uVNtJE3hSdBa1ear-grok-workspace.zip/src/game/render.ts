import { basis } from "./math";
import { ARENA_R, LIFE, SOFT } from "./sim";
import type { Enemy, Hue, State } from "./types";

const INK = "#0a0a0b";
const TIDE = "46, 201, 182";
const AMBER = "212, 148, 74";
const DANGER = "225, 90, 74";
const GLASS = "244, 244, 245";

let nebula: HTMLCanvasElement | null = null;
let stars: Float32Array | null = null;

function ensureBg() {
  if (!nebula) {
    const c = document.createElement("canvas");
    c.width = 640;
    c.height = 640;
    const g = c.getContext("2d");
    if (!g) return;
    g.fillStyle = INK;
    g.fillRect(0, 0, 640, 640);
    const blobs = [
      { x: 160, y: 460, r: 280, rgb: TIDE },
      { x: 500, y: 180, r: 300, rgb: AMBER },
      { x: 320, y: 320, r: 180, rgb: GLASS },
    ];
    for (const b of blobs) {
      const rad = g.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
      rad.addColorStop(0, `rgba(${b.rgb}, 0.2)`);
      rad.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = rad;
      g.fillRect(0, 0, 640, 640);
    }
    nebula = c;
  }
  if (!stars) {
    stars = new Float32Array(160 * 3);
    for (let i = 0; i < 160; i++) {
      stars[i * 3] = Math.random();
      stars[i * 3 + 1] = Math.random();
      stars[i * 3 + 2] = 0.3 + Math.random() * 0.7;
    }
  }
}

function applyCam(ctx: CanvasRenderingContext2D, s: State, w: number, h: number) {
  ctx.translate(w / 2 + s.shakeX, h / 2 + s.shakeY);
  ctx.scale(s.zoom, -s.zoom);
  ctx.translate(-s.camX, -s.camY);
}

function hueRgb(h: Hue) {
  if (h === "tide") return TIDE;
  if (h === "amber") return AMBER;
  if (h === "danger") return DANGER;
  return GLASS;
}

function drawRibbon(ctx: CanvasRenderingContext2D, s: State, glow: boolean) {
  const lace = s.lace;
  for (let i = 0; i < lace.length - 1; i++) {
    const a = lace[i]!;
    const b = lace[i + 1]!;
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const len = Math.hypot(dx, dy);
    if (len < 0.001 || len > 48) continue;
    const nx = -dy / len;
    const ny = dx / len;
    const age = (a.age + b.age) * 0.5;
    const u = Math.min(1, age / LIFE);
    const hard = age >= SOFT;
    const alpha = (glow ? 0.5 : 0.92) * (1 - u * 0.55);
    const hw = (glow ? 18 : 5.2) * (hard ? 0.8 : 1);
    ctx.beginPath();
    ctx.moveTo(a.x + nx * hw, a.y + ny * hw);
    ctx.lineTo(b.x + nx * hw, b.y + ny * hw);
    ctx.lineTo(b.x - nx * hw, b.y - ny * hw);
    ctx.lineTo(a.x - nx * hw, a.y - ny * hw);
    ctx.closePath();
    ctx.fillStyle = hard ? `rgba(${AMBER}, ${alpha})` : `rgba(${TIDE}, ${alpha})`;
    ctx.fill();
  }
  if (glow) return;
  ctx.lineWidth = 1.6 / Math.max(0.4, s.zoom);
  ctx.lineCap = "round";
  for (let i = 0; i < lace.length - 1; i++) {
    const a = lace[i]!;
    const b = lace[i + 1]!;
    if (a.age > SOFT * 0.85) continue;
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    if (len < 0.001 || len > 48) continue;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.strokeStyle = `rgba(${GLASS}, ${0.8 * (1 - a.age / SOFT)})`;
    ctx.stroke();
  }
}

function poly(ctx: CanvasRenderingContext2D, pts: number[]) {
  ctx.beginPath();
  ctx.moveTo(pts[0]!, pts[1]!);
  for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i]!, pts[i + 1]!);
  ctx.closePath();
}

function drawEnemy(ctx: CanvasRenderingContext2D, e: Enemy, zoom: number, glow: boolean) {
  const { fx, fy, rx, ry } = basis(e.yaw);
  const rgb = e.kind === "lance" ? DANGER : e.kind === "spit" ? AMBER : e.kind === "split" ? GLASS : TIDE;
  if (glow) {
    ctx.fillStyle = `rgba(${rgb}, 0.85)`;
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.r * 1.35, 0, Math.PI * 2);
    ctx.fill();
    return;
  }
  ctx.fillStyle = e.flash > 0 ? `rgba(${GLASS}, 0.95)` : `rgba(${rgb}, 0.95)`;
  if (e.kind === "spit") {
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = e.yaw + (i / 6) * Math.PI * 2;
      const rad = e.r * (i % 2 === 0 ? 1 : 0.72);
      const x = e.x + Math.cos(a) * rad;
      const y = e.y + Math.sin(a) * rad;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  } else if (e.kind === "split") {
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = `rgba(${TIDE}, 0.9)`;
    poly(ctx, [
      e.x + fx * e.r * 0.7,
      e.y + fy * e.r * 0.7,
      e.x - fx * e.r * 0.45 + rx * e.r * 0.45,
      e.y - fy * e.r * 0.45 + ry * e.r * 0.45,
      e.x - fx * e.r * 0.45 - rx * e.r * 0.45,
      e.y - fy * e.r * 0.45 - ry * e.r * 0.45,
    ]);
    ctx.fill();
  } else {
    const nose = e.kind === "lance" ? e.r * 1.7 : e.r * 1.35;
    const tail = e.r * 0.9;
    const wide = e.r * 0.72;
    poly(ctx, [
      e.x + fx * nose,
      e.y + fy * nose,
      e.x - fx * tail + rx * wide,
      e.y - fy * tail + ry * wide,
      e.x - fx * tail * 0.4,
      e.y - fy * tail * 0.4,
      e.x - fx * tail - rx * wide,
      e.y - fy * tail - ry * wide,
    ]);
    ctx.fill();
  }
  if (e.kind === "lance" && e.state === 1) {
    ctx.strokeStyle = `rgba(${DANGER}, ${0.45 + 0.4 * Math.sin(e.timer * 30)})`;
    ctx.lineWidth = 2 / zoom;
    ctx.setLineDash([10 / zoom, 7 / zoom]);
    ctx.beginPath();
    ctx.moveTo(e.x, e.y);
    ctx.lineTo(e.x + e.dx * 220, e.y + e.dy * 220);
    ctx.stroke();
    ctx.setLineDash([]);
  }
  if (e.maxHp > 1 && e.hp < e.maxHp) {
    const ww = e.r * 1.6;
    ctx.fillStyle = `rgba(${GLASS}, 0.25)`;
    ctx.fillRect(e.x - ww / 2, e.y + e.r + 8, ww, 3 / zoom);
    ctx.fillStyle = `rgba(${GLASS}, 0.9)`;
    ctx.fillRect(e.x - ww / 2, e.y + e.r + 8, ww * (e.hp / e.maxHp), 3 / zoom);
  }
}

function drawShip(ctx: CanvasRenderingContext2D, s: State, glow: boolean) {
  const p = s.player;
  if (p.hp <= 0 && s.phase === "dead") return;
  if (!glow && p.iframe > 0 && Math.sin(s.t * 46) > 0.2 && s.phase === "play") return;
  const { fx, fy, rx, ry } = basis(p.yaw);
  const stretch = 1 + Math.min(1, Math.abs(p.speed) / 420) * 0.38;
  const nose = 28 * stretch;
  const tail = 16 / Math.sqrt(stretch);
  const wide = 12 / Math.sqrt(stretch);
  if (glow) {
    ctx.fillStyle = `rgba(${TIDE}, 0.9)`;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 20, 0, Math.PI * 2);
    ctx.fill();
    return;
  }
  ctx.fillStyle = `rgba(${GLASS}, 0.96)`;
  poly(ctx, [
    p.x + fx * nose,
    p.y + fy * nose,
    p.x - fx * tail + rx * wide,
    p.y - fy * tail + ry * wide,
    p.x - fx * tail * 0.45,
    p.y - fy * tail * 0.45,
    p.x - fx * tail - rx * wide,
    p.y - fy * tail - ry * wide,
  ]);
  ctx.fill();
  ctx.fillStyle = `rgba(${TIDE}, 0.95)`;
  poly(ctx, [
    p.x + fx * nose * 0.55,
    p.y + fy * nose * 0.55,
    p.x - fx * 4 + rx * 3.2,
    p.y - fy * 4 + ry * 3.2,
    p.x - fx * 4 - rx * 3.2,
    p.y - fy * 4 - ry * 3.2,
  ]);
  ctx.fill();
}

function drawFloor(ctx: CanvasRenderingContext2D, s: State) {
  const zoom = Math.max(0.35, s.zoom);
  ctx.beginPath();
  ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(8, 8, 10, 0.78)";
  ctx.fill();
  ctx.save();
  ctx.clip();
  const reach = (Math.max(1400, 900 / zoom));
  const minX = s.camX - reach;
  const maxX = s.camX + reach;
  const minY = s.camY - reach;
  const maxY = s.camY + reach;
  const gap = 96;
  ctx.lineWidth = 1 / zoom;
  ctx.strokeStyle = "rgba(244, 244, 245, 0.045)";
  ctx.beginPath();
  for (let x = Math.floor(minX / gap) * gap; x <= maxX; x += gap) {
    ctx.moveTo(x, minY);
    ctx.lineTo(x, maxY);
  }
  for (let y = Math.floor(minY / gap) * gap; y <= maxY; y += gap) {
    ctx.moveTo(minX, y);
    ctx.lineTo(maxX, y);
  }
  ctx.stroke();
  ctx.restore();

  ctx.lineWidth = 1.25 / zoom;
  ctx.strokeStyle = "rgba(244, 244, 245, 0.07)";
  for (const r of [160, 320, 520, 780, 1100, 1450]) {
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.lineWidth = 2 / zoom;
  ctx.strokeStyle = "rgba(244, 244, 245, 0.28)";
  ctx.beginPath();
  ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
  ctx.stroke();
}

function drawActors(ctx: CanvasRenderingContext2D, s: State, glow: boolean) {
  drawRibbon(ctx, s, glow);
  for (const e of s.enemies) if (e.alive) drawEnemy(ctx, e, s.zoom, glow);
  for (const b of s.bolts) {
    if (!b.alive) continue;
    ctx.fillStyle = glow ? `rgba(${AMBER}, 0.9)` : `rgba(${GLASS}, 0.95)`;
    ctx.beginPath();
    ctx.arc(b.x, b.y, glow ? 8 : 3.4, 0, Math.PI * 2);
    ctx.fill();
  }
  if (s.pulseR > 0) {
    ctx.strokeStyle = glow ? `rgba(${GLASS}, 0.7)` : `rgba(${TIDE}, 0.85)`;
    ctx.lineWidth = (glow ? 10 : 2.2) / Math.max(0.4, s.zoom);
    ctx.beginPath();
    ctx.arc(s.player.x, s.player.y, s.pulseR, 0, Math.PI * 2);
    ctx.stroke();
  }
  drawShip(ctx, s, glow);
  if (glow) return;
  for (const p of s.parts) {
    if (!p.alive) continue;
    const a = Math.max(0, p.life / p.max);
    ctx.fillStyle = `rgba(${hueRgb(p.hue)}, ${a})`;
    ctx.fillRect(p.x - p.size * 0.5, p.y - p.size * 0.5, p.size, p.size);
  }
}

function project(s: State, x: number, y: number, w: number, h: number) {
  return {
    x: (x - s.camX) * s.zoom + w / 2 + s.shakeX,
    y: (s.camY - y) * s.zoom + h / 2 + s.shakeY,
  };
}

export function render(
  view: CanvasRenderingContext2D,
  glow: CanvasRenderingContext2D,
  s: State,
  cssW: number,
  cssH: number,
  dpr: number,
) {
  ensureBg();
  const dt = Math.max(0.001, s.frameDt);
  const head = basis(s.player.yaw);
  const look = s.phase === "menu" ? 40 : 120;
  const tx = s.player.x + head.fx * look;
  const ty = s.player.y + head.fy * look;
  const k = 1 - Math.exp(-4.6 * dt);
  s.camX += (tx - s.camX) * k;
  s.camY += (ty - s.camY) * k;
  s.zoom = Math.min(cssW, cssH) / 680;
  const mag = s.reduce ? 0 : s.trauma * s.trauma;
  s.shakeX = Math.sin(s.t * 41.2) * 18 * mag;
  s.shakeY = Math.sin(s.t * 33.4 + 1.7) * 12 * mag;

  glow.setTransform(1, 0, 0, 1, 0, 0);
  glow.clearRect(0, 0, glow.canvas.width, glow.canvas.height);
  glow.setTransform(dpr, 0, 0, dpr, 0, 0);
  glow.save();
  applyCam(glow, s, cssW, cssH);
  drawActors(glow, s, true);
  glow.restore();

  view.setTransform(dpr, 0, 0, dpr, 0, 0);
  view.fillStyle = INK;
  view.fillRect(0, 0, cssW, cssH);

  if (nebula) {
    const nx = ((-s.camX * 0.06) % cssW) - cssW * 0.15;
    const ny = ((s.camY * 0.06) % cssH) - cssH * 0.15;
    view.globalAlpha = 0.9;
    view.drawImage(nebula, nx, ny, cssW * 1.4, cssH * 1.4);
    view.globalAlpha = 1;
  }
  if (stars) {
    view.fillStyle = `rgba(${GLASS}, 0.8)`;
    for (let i = 0; i < 160; i++) {
      const sx =
        ((stars[i * 3]! * cssW * 1.5 - s.camX * 0.12) % (cssW * 1.5) + cssW * 1.5) % (cssW * 1.5) -
        cssW * 0.25;
      const sy =
        ((stars[i * 3 + 1]! * cssH * 1.5 + s.camY * 0.12) % (cssH * 1.5) + cssH * 1.5) % (cssH * 1.5) -
        cssH * 0.25;
      const r = stars[i * 3 + 2]!;
      view.globalAlpha = 0.25 + r * 0.55;
      view.fillRect(sx, sy, r > 0.8 ? 2 : 1.2, r > 0.8 ? 2 : 1.2);
    }
    view.globalAlpha = 1;
  }

  view.save();
  applyCam(view, s, cssW, cssH);
  drawFloor(view, s);
  view.restore();

  view.save();
  view.filter = s.reduce ? "none" : "blur(16px)";
  view.globalCompositeOperation = "lighter";
  view.drawImage(glow.canvas, 0, 0, cssW, cssH);
  view.restore();

  view.save();
  applyCam(view, s, cssW, cssH);
  drawActors(view, s, false);
  view.restore();

  const vig = view.createRadialGradient(
    cssW / 2,
    cssH / 2,
    Math.min(cssW, cssH) * 0.28,
    cssW / 2,
    cssH / 2,
    Math.max(cssW, cssH) * 0.72,
  );
  vig.addColorStop(0, "rgba(0,0,0,0)");
  vig.addColorStop(1, "rgba(0,0,0,0.58)");
  view.fillStyle = vig;
  view.fillRect(0, 0, cssW, cssH);

  if (s.player.flash > 0 && !s.reduce) {
    view.fillStyle = `rgba(244,244,245,${s.player.flash * 0.35})`;
    view.fillRect(0, 0, cssW, cssH);
  }

  view.textAlign = "center";
  view.font = "600 13px Outfit, sans-serif";
  for (const f of s.floats) {
    if (!f.alive) continue;
    const p = project(s, f.x, f.y, cssW, cssH);
    view.globalAlpha = Math.max(0, f.life / f.max);
    view.fillStyle = "#f4f4f5";
    view.fillText(f.text, p.x, p.y);
  }
  view.globalAlpha = 1;

  if (s.bannerT > 0 && s.banner && s.phase !== "menu") {
    view.globalAlpha = Math.min(1, s.bannerT);
    view.font = "600 28px Syne, sans-serif";
    view.fillStyle = "#f4f4f5";
    view.fillText(s.banner, cssW / 2, 86);
    view.globalAlpha = 1;
  }
}
