import { clamp, radialDeadzone } from "./math";

const BLOCK = new Set(["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]);

export interface Sample {
  throttle: number;
  steer: number;
  pulse: boolean;
  dash: boolean;
  pause: boolean;
}

/**
 * Devices → one sample per display frame.
 * A / ← steer positive (player-left). D / → steer negative.
 * Stick and gamepad X are positive to the right, so they subtract.
 */
export class Input {
  private keys = new Set<string>();
  private forced: Set<string> | null = null;
  private steerOverride: number | null = null;
  private stickX = 0;
  private stickY = 0;
  private pulseLatch = false;
  private dashLatch = false;
  private prevPulse = false;
  private prevDash = false;
  private prevPause = false;
  private abort = new AbortController();

  constructor() {
    const opt = { signal: this.abort.signal };
    window.addEventListener("keydown", this.onKeyDown, opt);
    window.addEventListener("keyup", this.onKeyUp, opt);
    window.addEventListener("blur", this.clearHardware, opt);
    document.addEventListener("visibilitychange", this.onHide, opt);
  }

  destroy() {
    this.abort.abort();
    this.keys.clear();
  }

  /** QA probe. Empty list releases the override and returns to hardware keys. */
  setKeys(codes: string[]) {
    if (codes.length === 0) {
      this.forced = null;
      return;
    }
    if (!this.forced) this.forced = new Set();
    this.forced.clear();
    for (const c of codes) this.forced.add(c);
  }

  setSteer(v: number) {
    this.steerOverride = v;
  }

  setStick(x: number, y: number) {
    this.stickX = x;
    this.stickY = y;
  }

  latchPulse() {
    this.pulseLatch = true;
  }

  latchDash() {
    this.dashLatch = true;
  }

  /** Edges are true only on the frame they begin. Call once per animation frame. */
  sample(): Sample {
    const keys = this.forced ?? this.keys;
    let throttle = 0;
    let steer = 0;
    if (keys.has("KeyW") || keys.has("ArrowUp")) throttle += 1;
    if (keys.has("KeyS") || keys.has("ArrowDown")) throttle -= 1;
    if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
    if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;

    const pad = this.readPad();
    throttle += this.stickY + pad.y;
    steer += -this.stickX + -pad.x;
    throttle = clamp(throttle, -0.45, 1);
    steer = clamp(steer, -1, 1);
    if (this.steerOverride !== null) steer = clamp(this.steerOverride, -1, 1);

    const pulseDown = keys.has("Space") || this.pulseLatch || pad.pulse;
    const dashDown =
      keys.has("ShiftLeft") || keys.has("ShiftRight") || this.dashLatch || pad.dash;
    const pauseDown = keys.has("Escape") || keys.has("KeyP") || pad.pause;

    const pulse = pulseDown && !this.prevPulse;
    const dash = dashDown && !this.prevDash;
    const pause = pauseDown && !this.prevPause;
    this.prevPulse = pulseDown;
    this.prevDash = dashDown;
    this.prevPause = pauseDown;
    this.pulseLatch = false;
    this.dashLatch = false;

    return { throttle, steer, pulse, dash, pause };
  }

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys.add(e.code);
    if (BLOCK.has(e.code)) e.preventDefault();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };

  private clearHardware = () => {
    this.keys.clear();
  };

  private onHide = () => {
    if (document.hidden) this.keys.clear();
  };

  private readPad() {
    const out = { x: 0, y: 0, pulse: false, dash: false, pause: false };
    const nav = navigator as Navigator & { getGamepads?: () => Array<Gamepad | null> };
    if (!nav.getGamepads) return out;
    let pads: Array<Gamepad | null>;
    try {
      pads = nav.getGamepads();
    } catch {
      return out;
    }
    for (const p of pads) {
      if (!p || p.mapping !== "standard") continue;
      const dz = radialDeadzone(p.axes[0] ?? 0, -(p.axes[1] ?? 0));
      out.x = dz.x;
      out.y = dz.y;
      out.pulse = !!p.buttons[0]?.pressed;
      out.dash = !!(p.buttons[1]?.pressed || p.buttons[5]?.pressed);
      out.pause = !!p.buttons[9]?.pressed;
      break;
    }
    return out;
  }
}
