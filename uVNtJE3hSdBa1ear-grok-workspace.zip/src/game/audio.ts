export class AudioBus {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private music: GainNode | null = null;
  private sfx: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicNodes: OscillatorNode[] = [];
  private musicOn = false;
  volume = 0.8;
  muted = false;

  unlock() {
    if (!this.ctx) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      this.ctx = new Ctx({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.music = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.music.gain.value = 0.55;
      this.sfx.gain.value = 0.9;
      this.master.gain.value = this.outGain();
      this.music.connect(this.master);
      this.sfx.connect(this.master);
      this.master.connect(this.ctx.destination);
      const len = Math.floor(this.ctx.sampleRate * 0.25);
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  dispose() {
    for (const n of this.musicNodes) {
      try {
        n.stop();
      } catch {
        /* already stopped */
      }
    }
    this.musicNodes = [];
    this.musicOn = false;
    void this.ctx?.close();
    this.ctx = null;
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.applyGain();
  }

  setVolume(unit: number) {
    this.volume = Math.min(1, Math.max(0, unit));
    this.applyGain();
  }

  startMusic() {
    this.unlock();
    if (!this.ctx || !this.music || this.musicOn) return;
    this.musicOn = true;
    const ctx = this.ctx;
    const bed: Array<[number, OscillatorType, number]> = [
      [110, "sine", 0.045],
      [164.81, "triangle", 0.02],
      [55, "sine", 0.03],
    ];
    for (const [freq, type, vol] of bed) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = type;
      o.frequency.value = freq;
      g.gain.value = vol;
      o.connect(g);
      g.connect(this.music);
      o.start();
      this.musicNodes.push(o);
    }
  }

  cut() {
    const j = 0.94 + Math.random() * 0.12;
    this.tone(720 * j, 0.08, "triangle", 0.08, -380);
    this.noise(0.05, 0.04);
  }

  hit() {
    this.tone(90, 0.22, "sine", 0.16, -40);
    this.noise(0.12, 0.08);
  }

  dash() {
    this.tone(240, 0.12, "sawtooth", 0.04, 280);
    this.noise(0.09, 0.05);
  }

  pulse() {
    this.tone(180, 0.28, "sine", 0.1, -120);
  }

  boom() {
    this.tone(70, 0.4, "sine", 0.18, -30);
    this.noise(0.2, 0.07);
  }

  wave() {
    this.tone(440, 0.1, "sine", 0.05);
    this.tone(554, 0.14, "sine", 0.04);
  }

  private outGain() {
    if (this.muted) return 0;
    return this.volume * this.volume;
  }

  private applyGain() {
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(this.outGain(), this.ctx.currentTime, 0.02);
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    slide = 0,
  ) {
    const ctx = this.ctx;
    const sfx = this.sfx;
    if (!ctx || !sfx || this.muted || this.volume < 0.01) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(40, freq), t);
    if (slide !== 0) {
      o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    }
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(sfx);
    o.start(t);
    o.stop(t + dur + 0.03);
    o.onended = () => {
      o.disconnect();
      g.disconnect();
    };
  }

  private noise(dur: number, vol: number) {
    const ctx = this.ctx;
    const sfx = this.sfx;
    if (!ctx || !sfx || !this.noiseBuf || this.muted || this.volume < 0.01) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = ctx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = 900;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(sfx);
    src.start(t);
    src.stop(t + dur + 0.02);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      g.disconnect();
    };
  }
}
