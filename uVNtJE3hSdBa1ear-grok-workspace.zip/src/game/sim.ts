import { angDiff, basis, clamp, distPointSeg, hypot } from "./math";
import type { Effects, Enemy, Floater, FrameInput, Hue, Kind, Part, Pt, State } from "./types";

export const ARENA_R = 1700;
export const SOFT = 2.4;
export const LIFE = 3.55;
export const MAX_LACE = 420;
export const MAX_HP = 3;
const POOL_E = 36;
const POOL_B = 40;
const POOL_P = 320;
const POOL_F = 18;
const LACE_HIT = 8;
const NEWEST_SAFE = 36;

const noopFx: Effects = {
  cut() {},
  hit() {},
  dash() {},
  pulse() {},
  boom() {},
  wave() {},
};

class Spatial {
  private buckets = new Map<number, number[]>();
  private lists: number[][] = [];
  private n = 0;
  private cell = 96;

  clear() {
    this.buckets.clear();
    this.n = 0;
  }

  private take() {
    let list = this.lists[this.n];
    if (!list) {
      list = [];
      this.lists[this.n] = list;
    } else list.length = 0;
    this.n++;
    return list;
  }

  insert(i: number, x0: number, y0: number, x1: number, y1: number) {
    const s = this.cell;
    const xMin = Math.floor(Math.min(x0, x1) / s);
    const xMax = Math.floor(Math.max(x0, x1) / s);
    const yMin = Math.floor(Math.min(y0, y1) / s);
    const yMax = Math.floor(Math.max(y0, y1) / s);
    for (let y = yMin; y <= yMax; y++) {
      for (let x = xMin; x <= xMax; x++) {
        const k = (x * 73856093) ^ (y * 19349663);
        let b = this.buckets.get(k);
        if (!b) {
          b = this.take();
          this.buckets.set(k, b);
        }
        b.push(i);
      }
    }
  }

  query(x: number, y: number, r: number, out: number[]) {
    out.length = 0;
    const s = this.cell;
    const x0 = Math.floor((x - r) / s);
    const x1 = Math.floor((x + r) / s);
    const y0 = Math.floor((y - r) / s);
    const y1 = Math.floor((y + r) / s);
    for (let gy = y0; gy <= y1; gy++) {
      for (let gx = x0; gx <= x1; gx++) {
        const b = this.buckets.get((gx * 73856093) ^ (gy * 19349663));
        if (!b) continue;
        for (let i = 0; i < b.length; i++) out.push(b[i]!);
      }
    }
  }
}

const spatial = new Spatial();
const queryBuf: number[] = [];
const stamp = new Int32Array(MAX_LACE);
let stampId = 1;

function blankEnemy(): Enemy {
  return {
    alive: false,
    kind: "drift",
    x: 0,
    y: 0,
    yaw: 0,
    r: 14,
    hp: 1,
    maxHp: 1,
    state: 0,
    timer: 0,
    cool: 0,
    gen: 0,
    flash: 0,
    hurt: 0,
    dx: 1,
    dy: 0,
    nearMiss: false,
    pulseSeen: 0,
  };
}

function makeParts(): Part[] {
  return Array.from({ length: POOL_P }, () => ({
    alive: false,
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    life: 0,
    max: 1,
    size: 2,
    hue: "glass" as Hue,
  }));
}

function makeFloats(): Floater[] {
  return Array.from({ length: POOL_F }, () => ({
    alive: false,
    x: 0,
    y: 0,
    life: 0,
    max: 1,
    text: "",
  }));
}

export function createState(): State {
  return {
    phase: "menu",
    t: 0,
    player: {
      x: 0,
      y: 0,
      yaw: 0,
      speed: 0,
      hp: MAX_HP,
      iframe: 0,
      flash: 0,
      dashT: 0,
      dashCd: 0,
      pulseCd: 0,
      radius: 13,
    },
    enemies: Array.from({ length: POOL_E }, blankEnemy),
    bolts: Array.from({ length: POOL_B }, () => ({
      alive: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      life: 0,
    })),
    lace: [],
    parts: makeParts(),
    floats: makeFloats(),
    laceX: 0,
    laceY: 0,
    laceInit: false,
    score: 0,
    best: 0,
    combo: 0,
    comboT: 0,
    wave: 1,
    toSpawn: 0,
    spawnT: 0,
    rest: 0,
    waveClear: false,
    banner: "",
    bannerT: 0,
    toast: "",
    toastT: 0,
    camX: 0,
    camY: 0,
    shakeX: 0,
    shakeY: 0,
    trauma: 0,
    zoom: 1,
    frameDt: 1 / 60,
    hitstop: 0,
    reduce: false,
    pulseId: 0,
    pulseR: 0,
    menuSpawn: 0.6,
    moteT: 0,
  };
}

function killAll(s: State) {
  for (const e of s.enemies) e.alive = false;
  for (const b of s.bolts) b.alive = false;
  for (const p of s.parts) p.alive = false;
  for (const f of s.floats) f.alive = false;
  s.lace.length = 0;
  s.laceInit = false;
  s.pulseR = 0;
  s.hitstop = 0;
}

export function beginMenu(s: State) {
  killAll(s);
  s.phase = "menu";
  s.t = 0;
  s.score = 0;
  s.combo = 0;
  s.banner = "";
  s.bannerT = 0;
  s.toast = "";
  s.toastT = 0;
  for (let i = 0; i < 96; i++) {
    const a = i * 0.21;
    const r = 28 + i * 3.1;
    s.lace.push({
      x: Math.cos(a) * r,
      y: Math.sin(a) * r,
      age: ((96 - i) / 96) * 3.2,
    });
  }
  const last = s.lace[s.lace.length - 1]!;
  s.player.x = last.x;
  s.player.y = last.y;
  s.player.yaw = tangentYaw(last.x, last.y);
  s.player.speed = 240;
  s.player.hp = MAX_HP;
  s.player.iframe = 1;
  s.player.dashT = 0;
  s.player.dashCd = 0;
  s.player.pulseCd = 0;
  s.laceX = last.x;
  s.laceY = last.y;
  s.laceInit = true;
  s.camX = last.x;
  s.camY = last.y;
  s.menuSpawn = 0.2;
  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI * 2;
    spawnEnemy(s, "drift", Math.cos(a) * 180, Math.sin(a) * 180, 1);
  }
}

function tangentYaw(x: number, y: number) {
  const len = hypot(x, y) || 1;
  const tx = -y / len;
  const ty = x / len;
  return Math.atan2(-tx, ty);
}

export function beginRun(s: State) {
  killAll(s);
  s.phase = "play";
  s.t = 0;
  s.player.x = 0;
  s.player.y = 0;
  s.player.yaw = 0;
  s.player.speed = 0;
  s.player.hp = MAX_HP;
  s.player.iframe = 0.6;
  s.player.flash = 0;
  s.player.dashT = 0;
  s.player.dashCd = 0;
  s.player.pulseCd = 0;
  s.score = 0;
  s.combo = 0;
  s.comboT = 0;
  s.wave = 1;
  s.toSpawn = waveCount(1);
  s.spawnT = 1.35;
  s.rest = 0;
  s.waveClear = false;
  s.banner = "Wave 1";
  s.bannerT = 1.7;
  s.toast = "Fresh wake cuts. Amber wake cuts you.";
  s.toastT = 5.2;
  s.camX = 0;
  s.camY = 0;
  s.trauma = 0;
  s.laceInit = false;
}

function waveCount(wave: number) {
  return 3 + wave;
}

function pickKind(wave: number): Kind {
  const r = Math.random();
  if (wave >= 5 && r < 0.14) return "split";
  if (wave >= 3 && r < 0.36) return "spit";
  if (wave >= 2 && r < 0.6) return "lance";
  return "drift";
}

function spawnEnemy(s: State, kind: Kind, x: number, y: number, gen: number) {
  const e = s.enemies.find((en) => !en.alive);
  if (!e) return;
  e.alive = true;
  e.kind = kind;
  e.x = x;
  e.y = y;
  e.yaw = Math.random() * Math.PI * 2;
  e.hp = kind === "split" ? 4 : kind === "spit" ? 2 : 1;
  e.maxHp = e.hp;
  e.r = kind === "split" ? 26 : kind === "lance" ? 16 : 14;
  e.state = 0;
  e.timer = 0;
  e.cool = 0.6 + Math.random() * 0.6;
  e.gen = gen;
  e.flash = 0;
  e.hurt = 0;
  e.dx = 1;
  e.dy = 0;
  e.nearMiss = false;
  e.pulseSeen = 0;
}

function burst(s: State, x: number, y: number, hue: Hue, n: number) {
  const count = s.reduce ? Math.min(4, n) : n;
  let left = count;
  for (const p of s.parts) {
    if (p.alive) continue;
    const a = Math.random() * Math.PI * 2;
    const sp = 30 + Math.random() * 240;
    p.alive = true;
    p.x = x;
    p.y = y;
    p.vx = Math.cos(a) * sp;
    p.vy = Math.sin(a) * sp;
    p.max = 0.28 + Math.random() * 0.42;
    p.life = p.max;
    p.size = 1.4 + Math.random() * 2.4;
    p.hue = hue;
    if (--left <= 0) break;
  }
}

function floater(s: State, x: number, y: number, text: string) {
  if (s.phase !== "play") return;
  const f = s.floats.find((fl) => !fl.alive);
  if (!f) return;
  f.alive = true;
  f.x = x;
  f.y = y;
  f.max = 0.8;
  f.life = 0.8;
  f.text = text;
}

function addScore(s: State, pts: number, x: number, y: number) {
  if (s.phase !== "play") return;
  s.score += pts;
  floater(s, x, y, `+${pts}`);
}

function killEnemy(s: State, e: Enemy, fx: Effects) {
  e.alive = false;
  const hue: Hue = e.kind === "lance" ? "danger" : e.kind === "spit" ? "amber" : "tide";
  burst(s, e.x, e.y, hue, e.kind === "split" ? 22 : 12);
  if (e.kind === "split" && e.gen === 0) {
    spawnEnemy(s, "drift", e.x + 22, e.y + 8, 1);
    spawnEnemy(s, "drift", e.x - 22, e.y - 8, 1);
  }
  if (s.phase !== "play") {
    fx.cut();
    return;
  }
  s.combo += 1;
  s.comboT = 2.55;
  const chain = 70 + (s.combo - 1) * 28;
  const kindBonus = e.kind === "lance" ? 40 : e.kind === "spit" ? 50 : e.kind === "split" ? 90 : 0;
  addScore(s, chain + kindBonus, e.x, e.y);
  fx.cut();
  s.trauma = Math.min(1, s.trauma + (e.kind === "split" ? 0.45 : 0.22));
  if (e.kind === "split" || s.combo % 6 === 0) s.hitstop = Math.max(s.hitstop, 0.045);
}

function hurtPlayer(s: State, fx: Effects, kx: number, ky: number, label: string) {
  const p = s.player;
  if (s.phase !== "play" || p.iframe > 0 || p.dashT > 0) return;
  p.hp -= 1;
  p.iframe = 1.15;
  p.flash = 0.18;
  p.speed *= 0.35;
  p.x += kx;
  p.y += ky;
  s.combo = 0;
  s.comboT = 0;
  s.hitstop = 0.07;
  s.trauma = Math.min(1, s.trauma + 0.72);
  floater(s, p.x, p.y + 18, label);
  if (p.hp <= 0) {
    s.phase = "dead";
    burst(s, p.x, p.y, "glass", 36);
    burst(s, p.x, p.y, "amber", 16);
    fx.boom();
    if (s.score > s.best) s.best = s.score;
    s.banner = "Wake closed";
    s.bannerT = 2.4;
  } else {
    fx.hit();
  }
}

function damageEnemy(s: State, e: Enemy, fx: Effects, force = false) {
  if (!e.alive) return;
  if (!force && e.hurt > 0) return;
  e.hp -= 1;
  e.hurt = 0.16;
  e.flash = 0.1;
  if (e.hp <= 0) killEnemy(s, e, fx);
  else fx.cut();
}

function fireBolt(s: State, x: number, y: number, tx: number, ty: number) {
  const b = s.bolts.find((bolt) => !bolt.alive);
  if (!b) return;
  const d = hypot(tx - x, ty - y) || 1;
  const sp = 175;
  b.alive = true;
  b.x = x;
  b.y = y;
  b.vx = ((tx - x) / d) * sp;
  b.vy = ((ty - y) / d) * sp;
  b.life = 3.4;
}

function contain(x: number, y: number, margin: number) {
  const d = hypot(x, y);
  const lim = ARENA_R - margin;
  if (d <= lim || d < 1e-4) return { x, y, hit: false, nx: 0, ny: 0 };
  return { x: (x / d) * lim, y: (y / d) * lim, hit: true, nx: x / d, ny: y / d };
}

function compactLace(s: State) {
  const lace = s.lace;
  let w = 0;
  for (let i = 0; i < lace.length; i++) {
    const p = lace[i]!;
    if (p.age <= LIFE) lace[w++] = p;
  }
  lace.length = w;
}

function ageLace(s: State, dt: number) {
  const lace = s.lace;
  for (let i = 0; i < lace.length; i++) lace[i]!.age += dt;
  compactLace(s);
  if (s.lace.length > MAX_LACE) s.lace.splice(0, s.lace.length - MAX_LACE);
}

function emitLace(s: State) {
  const p = s.player;
  if (!s.laceInit) {
    s.laceInit = true;
    s.laceX = p.x;
    s.laceY = p.y;
    return;
  }
  const dx = p.x - s.laceX;
  const dy = p.y - s.laceY;
  const dist = hypot(dx, dy);
  const stepD = p.dashT > 0 ? 7 : 11;
  if (dist < stepD) return;
  const n = Math.min(5, Math.floor(dist / stepD));
  for (let i = 1; i <= n; i++) {
    const t = (i * stepD) / dist;
    const pt: Pt = { x: s.laceX + dx * t, y: s.laceY + dy * t, age: 0 };
    s.lace.push(pt);
  }
  const used = n * stepD;
  s.laceX += (dx * used) / dist;
  s.laceY += (dy * used) / dist;
}

function rebuildHash(s: State) {
  spatial.clear();
  const lace = s.lace;
  for (let i = 0; i < lace.length - 1; i++) {
    const a = lace[i]!;
    const b = lace[i + 1]!;
    if (hypot(b.x - a.x, b.y - a.y) > 48) continue;
    spatial.insert(i, a.x, a.y, b.x, b.y);
  }
}

function uniqueQuery(x: number, y: number, r: number) {
  stampId++;
  if (stampId > 1_800_000_000) {
    stamp.fill(0);
    stampId = 1;
  }
  spatial.query(x, y, r, queryBuf);
  let w = 0;
  for (let i = 0; i < queryBuf.length; i++) {
    const idx = queryBuf[i]!;
    if (idx < 0 || idx >= MAX_LACE) continue;
    if (stamp[idx] === stampId) continue;
    stamp[idx] = stampId;
    queryBuf[w++] = idx;
  }
  queryBuf.length = w;
  return queryBuf;
}

function steerTo(e: Enemy, tx: number, ty: number, rate: number, dt: number) {
  const desired = Math.atan2(-(tx - e.x), ty - e.y);
  const d = clamp(angDiff(e.yaw, desired), -rate * dt, rate * dt);
  e.yaw += d;
}

function updateEnemy(s: State, e: Enemy, dt: number) {
  const p = s.player;
  e.hurt = Math.max(0, e.hurt - dt);
  e.flash = Math.max(0, e.flash - dt);
  e.cool -= dt;
  const d = hypot(p.x - e.x, p.y - e.y);

  if (e.kind === "drift" || (e.kind === "split" && e.gen > 0)) {
    steerTo(e, p.x, p.y, 2.5, dt);
    const { fx, fy } = basis(e.yaw);
    const sp = 115 + Math.min(70, s.wave * 6);
    e.x += fx * sp * dt;
    e.y += fy * sp * dt;
  } else if (e.kind === "split") {
    steerTo(e, p.x, p.y, 1.5, dt);
    const { fx, fy } = basis(e.yaw);
    e.x += fx * 88 * dt;
    e.y += fy * 88 * dt;
  } else if (e.kind === "lance") {
    e.timer -= dt;
    if (e.state === 0) {
      steerTo(e, p.x, p.y, 2.2, dt);
      const { fx, fy } = basis(e.yaw);
      const sp = d > 360 ? 150 : 50;
      e.x += fx * sp * dt;
      e.y += fy * sp * dt;
      if (d < 430 && d > 160 && e.cool <= 0) {
        e.state = 1;
        e.timer = 0.56;
        e.dx = (p.x - e.x) / (d || 1);
        e.dy = (p.y - e.y) / (d || 1);
        e.nearMiss = false;
      }
    } else if (e.state === 1) {
      if (e.timer > 0.38) {
        const dd = hypot(p.x - e.x, p.y - e.y) || 1;
        e.dx = (p.x - e.x) / dd;
        e.dy = (p.y - e.y) / dd;
      }
      if (e.timer <= 0) {
        e.state = 2;
        e.timer = 0.32;
      }
    } else if (e.state === 2) {
      e.x += e.dx * 620 * dt;
      e.y += e.dy * 620 * dt;
      if (!e.nearMiss && d < 48 && d > p.radius + e.r + 2 && s.phase === "play") {
        e.nearMiss = true;
        addScore(s, 25, p.x, p.y + 24);
      }
      if (e.timer <= 0) {
        e.state = 3;
        e.timer = 0.48;
        e.cool = 1.15;
      }
    } else if (e.timer <= 0) {
      e.state = 0;
    }
  } else {
    const away = d < 230;
    let tx: number;
    let ty: number;
    if (away) {
      tx = e.x + (e.x - p.x);
      ty = e.y + (e.y - p.y);
    } else {
      const inv = d || 1;
      const px = -(p.y - e.y) / inv;
      const py = (p.x - e.x) / inv;
      tx = p.x + px * 300;
      ty = p.y + py * 300;
    }
    steerTo(e, tx, ty, 2.4, dt);
    const { fx, fy } = basis(e.yaw);
    e.x += fx * 108 * dt;
    e.y += fy * 108 * dt;
    if (e.cool <= 0 && d < 560 && s.phase === "play") {
      const nose = basis(e.yaw);
      fireBolt(s, e.x + nose.fx * e.r, e.y + nose.fy * e.r, p.x, p.y);
      e.cool = Math.max(1.15, 1.85 - s.wave * 0.06);
    }
  }

  const c = contain(e.x, e.y, e.r + 8);
  e.x = c.x;
  e.y = c.y;
}

function updateBolts(s: State, dt: number, fx: Effects) {
  const p = s.player;
  for (const b of s.bolts) {
    if (!b.alive) continue;
    b.life -= dt;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    if (b.life <= 0 || hypot(b.x, b.y) > ARENA_R) {
      b.alive = false;
      continue;
    }
    const hits = uniqueQuery(b.x, b.y, 12);
    for (let i = 0; i < hits.length; i++) {
      const idx = hits[i]!;
      const a = s.lace[idx];
      const c = s.lace[idx + 1];
      if (!a || !c) continue;
      if (distPointSeg(b.x, b.y, a.x, a.y, c.x, c.y) < 10) {
        b.alive = false;
        burst(s, b.x, b.y, "amber", 5);
        addScore(s, 15, b.x, b.y);
        break;
      }
    }
    if (!b.alive) continue;
    if (hypot(b.x - p.x, b.y - p.y) < p.radius + 6) {
      b.alive = false;
      const d = hypot(b.vx, b.vy) || 1;
      hurtPlayer(s, fx, (b.vx / d) * 18, (b.vy / d) * 18, "BOLT");
    }
  }
}

function collideLace(s: State, fx: Effects) {
  const p = s.player;
  const lace = s.lace;
  const safeFrom = Math.max(0, lace.length - NEWEST_SAFE);

  for (const e of s.enemies) {
    if (!e.alive) continue;
    const hits = uniqueQuery(e.x, e.y, e.r + LACE_HIT + 4);
    for (let i = 0; i < hits.length; i++) {
      const idx = hits[i]!;
      const a = lace[idx];
      const b = lace[idx + 1];
      if (!a || !b) continue;
      if (distPointSeg(e.x, e.y, a.x, a.y, b.x, b.y) <= e.r + LACE_HIT) {
        damageEnemy(s, e, fx);
        break;
      }
    }
  }

  if (s.phase !== "play" || p.iframe > 0 || p.dashT > 0) return;
  const hits = uniqueQuery(p.x, p.y, p.radius + LACE_HIT + 4);
  for (let i = 0; i < hits.length; i++) {
    const idx = hits[i]!;
    if (idx >= safeFrom) continue;
    const a = lace[idx];
    const b = lace[idx + 1];
    if (!a || !b) continue;
    const age = (a.age + b.age) * 0.5;
    if (age < SOFT) continue;
    if (distPointSeg(p.x, p.y, a.x, a.y, b.x, b.y) <= p.radius + LACE_HIT - 1) {
      const mx = (a.x + b.x) * 0.5;
      const my = (a.y + b.y) * 0.5;
      const d = hypot(p.x - mx, p.y - my) || 1;
      hurtPlayer(s, fx, ((p.x - mx) / d) * 22, ((p.y - my) / d) * 22, "WAKE");
      break;
    }
  }
}

function collideBodies(s: State, fx: Effects) {
  const p = s.player;
  if (s.phase !== "play" || p.iframe > 0 || p.dashT > 0) return;
  for (const e of s.enemies) {
    if (!e.alive) continue;
    const d = hypot(e.x - p.x, e.y - p.y);
    if (d < e.r + p.radius) {
      const inv = d || 1;
      hurtPlayer(s, fx, ((p.x - e.x) / inv) * 26, ((p.y - e.y) / inv) * 26, "HIT");
      e.hurt = Math.max(e.hurt, 0.3);
      break;
    }
  }
}

function doPulse(s: State, fx: Effects) {
  const p = s.player;
  if (s.phase !== "play" || p.pulseCd > 0) return;
  p.pulseCd = 3.25;
  s.pulseId += 1;
  s.pulseR = 30;
  s.trauma = Math.min(1, s.trauma + 0.4);
  fx.pulse();
  const id = s.pulseId;
  for (const pt of s.lace) {
    if (hypot(pt.x - p.x, pt.y - p.y) < 70) pt.age = LIFE + 1;
  }
  for (const e of s.enemies) {
    if (!e.alive) continue;
    if (hypot(e.x - p.x, e.y - p.y) < 78) {
      e.pulseSeen = id;
      damageEnemy(s, e, fx, true);
      const d = hypot(e.x - p.x, e.y - p.y) || 1;
      e.x += ((e.x - p.x) / d) * 40;
      e.y += ((e.y - p.y) / d) * 40;
    }
  }
}

function expandPulse(s: State, dt: number, fx: Effects) {
  if (s.pulseR <= 0) return;
  s.pulseR += dt * 860;
  if (s.pulseR > 280) {
    s.pulseR = 0;
    return;
  }
  const p = s.player;
  const id = s.pulseId;
  for (const pt of s.lace) {
    if (hypot(pt.x - p.x, pt.y - p.y) < s.pulseR) pt.age = LIFE + 1;
  }
  for (const e of s.enemies) {
    if (!e.alive || e.pulseSeen === id) continue;
    const d = hypot(e.x - p.x, e.y - p.y);
    if (d <= s.pulseR && d >= s.pulseR - 36) {
      e.pulseSeen = id;
      damageEnemy(s, e, fx, true);
      const inv = d || 1;
      e.x += ((e.x - p.x) / inv) * 28;
      e.y += ((e.y - p.y) / inv) * 28;
    }
  }
  for (const b of s.bolts) {
    if (!b.alive) continue;
    if (hypot(b.x - p.x, b.y - p.y) < s.pulseR) b.alive = false;
  }
  compactLace(s);
}

function updateDirector(s: State, dt: number, fx: Effects) {
  if (s.phase === "menu") {
    s.menuSpawn -= dt;
    if (s.menuSpawn <= 0) {
      s.menuSpawn = 1.3;
      let alive = 0;
      for (const e of s.enemies) if (e.alive) alive++;
      if (alive < 4) {
        const a = Math.random() * Math.PI * 2;
        const kind: Kind = Math.random() < 0.25 ? "lance" : "drift";
        spawnEnemy(s, kind, s.player.x + Math.cos(a) * 260, s.player.y + Math.sin(a) * 260, 1);
      }
    }
    return;
  }
  if (s.phase !== "play") return;

  if (s.waveClear) {
    s.rest -= dt;
    if (s.rest <= 0) {
      s.wave += 1;
      s.toSpawn = waveCount(s.wave);
      s.spawnT = 0.45;
      s.waveClear = false;
      s.banner = `Wave ${s.wave}`;
      s.bannerT = 1.6;
    }
    return;
  }

  if (s.toSpawn > 0) {
    s.spawnT -= dt;
    if (s.spawnT <= 0) {
      const a = Math.random() * Math.PI * 2;
      const dist = 480 + Math.random() * 180;
      let x = s.player.x + Math.cos(a) * dist;
      let y = s.player.y + Math.sin(a) * dist;
      const c = contain(x, y, 80);
      x = c.x;
      y = c.y;
      spawnEnemy(s, pickKind(s.wave), x, y, 0);
      s.toSpawn -= 1;
      s.spawnT = Math.max(0.38, 0.92 - s.wave * 0.04);
    }
    return;
  }

  let alive = 0;
  for (const e of s.enemies) if (e.alive) alive++;
  if (alive === 0) {
    s.waveClear = true;
    s.rest = 2.05;
    const bonus = 140 + s.wave * 45;
    s.score += bonus;
    floater(s, s.player.x, s.player.y + 30, `WAVE +${bonus}`);
    fx.wave();
  }
}

function updateParts(s: State, dt: number) {
  for (const p of s.parts) {
    if (!p.alive) continue;
    p.life -= dt;
    if (p.life <= 0) {
      p.alive = false;
      continue;
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    const drag = Math.exp(-1.6 * dt);
    p.vx *= drag;
    p.vy *= drag;
  }
  for (const f of s.floats) {
    if (!f.alive) continue;
    f.life -= dt;
    if (f.life <= 0) f.alive = false;
    else f.y += 28 * dt;
  }
  s.bannerT = Math.max(0, s.bannerT - dt);
  s.toastT = Math.max(0, s.toastT - dt);
  s.moteT -= dt;
  if (s.moteT <= 0) {
    s.moteT = 0.22;
    const a = Math.random() * Math.PI * 2;
    const rad = Math.random() * 200;
    burst(s, s.player.x + Math.cos(a) * rad, s.player.y + Math.sin(a) * rad, "glass", 1);
  }
}

export function step(s: State, input: FrameInput, dt: number, fx: Effects = noopFx) {
  s.t += dt;
  const p = s.player;
  p.iframe = Math.max(0, p.iframe - dt);
  p.flash = Math.max(0, p.flash - dt);
  p.dashCd = Math.max(0, p.dashCd - dt);
  p.pulseCd = Math.max(0, p.pulseCd - dt);
  s.trauma = Math.max(0, s.trauma - dt * 1.55);
  s.comboT = Math.max(0, s.comboT - dt);
  if (s.comboT <= 0) s.combo = 0;

  if (s.phase === "pause") return;

  if (s.hitstop > 0 && s.phase === "play") {
    s.hitstop -= dt;
    updateParts(s, dt * 0.25);
    return;
  }

  if (s.phase === "dead") {
    updateParts(s, dt);
    expandPulse(s, dt, fx);
    return;
  }

  if (s.phase === "menu") {
    p.yaw += (0.65 + Math.sin(s.t * 0.85) * 1.05) * dt;
    p.speed = 235 + Math.sin(s.t * 0.45) * 30;
    p.iframe = 1;
  } else {
    if (input.dash && p.dashCd <= 0 && p.dashT <= 0) {
      p.dashT = 0.16;
      p.dashCd = 1.15;
      fx.dash();
      s.trauma = Math.min(1, s.trauma + 0.18);
    }
    if (input.pulse) doPulse(s, fx);
    if (p.dashT > 0) {
      p.dashT -= dt;
      p.speed = 730;
      p.iframe = Math.max(p.iframe, 0.05);
    } else if (input.throttle > 0.05) {
      const target = 360 * input.throttle;
      p.speed += (target - p.speed) * (1 - Math.exp(-3.4 * dt));
    } else if (input.throttle < -0.05) {
      p.speed += (-130 - p.speed) * (1 - Math.exp(-4.2 * dt));
    } else {
      p.speed *= Math.exp(-1.25 * dt);
    }
    const spf = clamp(Math.abs(p.speed) / 80, 0.55, 1);
    const reverse = p.speed >= -8 ? 1 : -1;
    p.yaw += input.steer * 2.75 * spf * reverse * dt;
  }

  const head = basis(p.yaw);
  p.x += head.fx * p.speed * dt;
  p.y += head.fy * p.speed * dt;
  const wall = contain(p.x, p.y, 22);
  if (wall.hit) {
    p.x = wall.x;
    p.y = wall.y;
    const outward = head.fx * wall.nx + head.fy * wall.ny;
    if (outward > 0 && p.speed > 0) p.speed *= 0.45;
  }

  emitLace(s);
  ageLace(s, dt);
  expandPulse(s, dt, fx);

  for (const e of s.enemies) {
    if (e.alive) updateEnemy(s, e, dt);
  }
  rebuildHash(s);
  updateBolts(s, dt, fx);
  collideLace(s, fx);
  collideBodies(s, fx);
  updateDirector(s, dt, fx);
  updateParts(s, dt);
}
