export function clamp(v: number, a: number, b: number) {
  return v < a ? a : v > b ? b : v;
}

export function hypot(x: number, y: number) {
  return Math.hypot(x, y);
}

/** Shortest signed angle a → b, in radians. */
export function angDiff(a: number, b: number) {
  return Math.atan2(Math.sin(b - a), Math.cos(b - a));
}

export function basis(yaw: number) {
  const fx = -Math.sin(yaw);
  const fy = Math.cos(yaw);
  const rx = Math.cos(yaw);
  const ry = Math.sin(yaw);
  return { fx, fy, rx, ry };
}

export function distPointSeg(
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number,
) {
  const abx = bx - ax;
  const aby = by - ay;
  const apx = px - ax;
  const apy = py - ay;
  const ab2 = abx * abx + aby * aby;
  let t = ab2 > 1e-8 ? (apx * abx + apy * aby) / ab2 : 0;
  if (t < 0) t = 0;
  else if (t > 1) t = 1;
  const dx = px - (ax + abx * t);
  const dy = py - (ay + aby * t);
  return Math.hypot(dx, dy);
}

/** Radial stick deadzone with re-normalization so a full tilt still reaches 1. */
export function radialDeadzone(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz || m < 1e-6) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}
