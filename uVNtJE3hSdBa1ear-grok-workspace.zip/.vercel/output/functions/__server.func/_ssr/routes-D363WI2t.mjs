import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Pause, n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D363WI2t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AudioBus = class {
	ctx = null;
	master = null;
	music = null;
	sfx = null;
	noiseBuf = null;
	musicNodes = [];
	musicOn = false;
	volume = .8;
	muted = false;
	unlock() {
		if (!this.ctx) {
			const Ctx = window.AudioContext || window.webkitAudioContext;
			if (!Ctx) return;
			this.ctx = new Ctx({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.music = this.ctx.createGain();
			this.sfx = this.ctx.createGain();
			this.music.gain.value = .55;
			this.sfx.gain.value = .9;
			this.master.gain.value = this.outGain();
			this.music.connect(this.master);
			this.sfx.connect(this.master);
			this.master.connect(this.ctx.destination);
			const len = Math.floor(this.ctx.sampleRate * .25);
			this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
			const data = this.noiseBuf.getChannelData(0);
			for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	resume() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	dispose() {
		for (const n of this.musicNodes) try {
			n.stop();
		} catch {}
		this.musicNodes = [];
		this.musicOn = false;
		this.ctx?.close();
		this.ctx = null;
	}
	setMuted(m) {
		this.muted = m;
		this.applyGain();
	}
	setVolume(unit) {
		this.volume = Math.min(1, Math.max(0, unit));
		this.applyGain();
	}
	startMusic() {
		this.unlock();
		if (!this.ctx || !this.music || this.musicOn) return;
		this.musicOn = true;
		const ctx = this.ctx;
		for (const [freq, type, vol] of [
			[
				110,
				"sine",
				.045
			],
			[
				164.81,
				"triangle",
				.02
			],
			[
				55,
				"sine",
				.03
			]
		]) {
			const o = ctx.createOscillator();
			const g = ctx.createGain();
			o.type = type;
			o.frequency.value = freq;
			g.gain.value = vol;
			o.connect(g);
			g.connect(this.music);
			o.start();
			this.musicNodes.push(o);
		}
	}
	cut() {
		const j = .94 + Math.random() * .12;
		this.tone(720 * j, .08, "triangle", .08, -380);
		this.noise(.05, .04);
	}
	hit() {
		this.tone(90, .22, "sine", .16, -40);
		this.noise(.12, .08);
	}
	dash() {
		this.tone(240, .12, "sawtooth", .04, 280);
		this.noise(.09, .05);
	}
	pulse() {
		this.tone(180, .28, "sine", .1, -120);
	}
	boom() {
		this.tone(70, .4, "sine", .18, -30);
		this.noise(.2, .07);
	}
	wave() {
		this.tone(440, .1, "sine", .05);
		this.tone(554, .14, "sine", .04);
	}
	outGain() {
		if (this.muted) return 0;
		return this.volume * this.volume;
	}
	applyGain() {
		if (!this.ctx || !this.master) return;
		this.master.gain.setTargetAtTime(this.outGain(), this.ctx.currentTime, .02);
	}
	tone(freq, dur, type, vol, slide = 0) {
		const ctx = this.ctx;
		const sfx = this.sfx;
		if (!ctx || !sfx || this.muted || this.volume < .01) return;
		const t = ctx.currentTime;
		const o = ctx.createOscillator();
		const g = ctx.createGain();
		o.type = type;
		o.frequency.setValueAtTime(Math.max(40, freq), t);
		if (slide !== 0) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(Math.max(2e-4, vol), t + .012);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		o.connect(g);
		g.connect(sfx);
		o.start(t);
		o.stop(t + dur + .03);
		o.onended = () => {
			o.disconnect();
			g.disconnect();
		};
	}
	noise(dur, vol) {
		const ctx = this.ctx;
		const sfx = this.sfx;
		if (!ctx || !sfx || !this.noiseBuf || this.muted || this.volume < .01) return;
		const t = ctx.currentTime;
		const src = ctx.createBufferSource();
		src.buffer = this.noiseBuf;
		const filter = ctx.createBiquadFilter();
		filter.type = "highpass";
		filter.frequency.value = 900;
		const g = ctx.createGain();
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(Math.max(2e-4, vol), t + .008);
		g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		src.connect(filter);
		filter.connect(g);
		g.connect(sfx);
		src.start(t);
		src.stop(t + dur + .02);
		src.onended = () => {
			src.disconnect();
			filter.disconnect();
			g.disconnect();
		};
	}
};
function clamp(v, a, b) {
	return v < a ? a : v > b ? b : v;
}
function hypot(x, y) {
	return Math.hypot(x, y);
}
/** Shortest signed angle a → b, in radians. */
function angDiff(a, b) {
	return Math.atan2(Math.sin(b - a), Math.cos(b - a));
}
function basis(yaw) {
	return {
		fx: -Math.sin(yaw),
		fy: Math.cos(yaw),
		rx: Math.cos(yaw),
		ry: Math.sin(yaw)
	};
}
function distPointSeg(px, py, ax, ay, bx, by) {
	const abx = bx - ax;
	const aby = by - ay;
	const apx = px - ax;
	const apy = py - ay;
	const ab2 = abx * abx + aby * aby;
	let t = ab2 > 1e-8 ? (apx * abx + apy * aby) / ab2 : 0;
	if (t < 0) t = 0;
	else if (t > 1) t = 1;
	const dx = px - (ax + abx * t);
	const dy = py - (ay + aby * t);
	return Math.hypot(dx, dy);
}
/** Radial stick deadzone with re-normalization so a full tilt still reaches 1. */
function radialDeadzone(x, y, dz = .18) {
	const m = Math.hypot(x, y);
	if (m < dz || m < 1e-6) return {
		x: 0,
		y: 0
	};
	const scale = (m - dz) / (1 - dz) / m;
	return {
		x: x * scale,
		y: y * scale
	};
}
var BLOCK = /* @__PURE__ */ new Set([
	"Space",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight"
]);
/**
* Devices → one sample per display frame.
* A / ← steer positive (player-left). D / → steer negative.
* Stick and gamepad X are positive to the right, so they subtract.
*/
var Input = class {
	keys = /* @__PURE__ */ new Set();
	forced = null;
	steerOverride = null;
	stickX = 0;
	stickY = 0;
	pulseLatch = false;
	dashLatch = false;
	prevPulse = false;
	prevDash = false;
	prevPause = false;
	abort = new AbortController();
	constructor() {
		const opt = { signal: this.abort.signal };
		window.addEventListener("keydown", this.onKeyDown, opt);
		window.addEventListener("keyup", this.onKeyUp, opt);
		window.addEventListener("blur", this.clearHardware, opt);
		document.addEventListener("visibilitychange", this.onHide, opt);
	}
	destroy() {
		this.abort.abort();
		this.keys.clear();
	}
	/** QA probe. Empty list releases the override and returns to hardware keys. */
	setKeys(codes) {
		if (codes.length === 0) {
			this.forced = null;
			return;
		}
		if (!this.forced) this.forced = /* @__PURE__ */ new Set();
		this.forced.clear();
		for (const c of codes) this.forced.add(c);
	}
	setSteer(v) {
		this.steerOverride = v;
	}
	setStick(x, y) {
		this.stickX = x;
		this.stickY = y;
	}
	latchPulse() {
		this.pulseLatch = true;
	}
	latchDash() {
		this.dashLatch = true;
	}
	/** Edges are true only on the frame they begin. Call once per animation frame. */
	sample() {
		const keys = this.forced ?? this.keys;
		let throttle = 0;
		let steer = 0;
		if (keys.has("KeyW") || keys.has("ArrowUp")) throttle += 1;
		if (keys.has("KeyS") || keys.has("ArrowDown")) throttle -= 1;
		if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
		if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;
		const pad = this.readPad();
		throttle += this.stickY + pad.y;
		steer += -this.stickX + -pad.x;
		throttle = clamp(throttle, -.45, 1);
		steer = clamp(steer, -1, 1);
		if (this.steerOverride !== null) steer = clamp(this.steerOverride, -1, 1);
		const pulseDown = keys.has("Space") || this.pulseLatch || pad.pulse;
		const dashDown = keys.has("ShiftLeft") || keys.has("ShiftRight") || this.dashLatch || pad.dash;
		const pauseDown = keys.has("Escape") || keys.has("KeyP") || pad.pause;
		const pulse = pulseDown && !this.prevPulse;
		const dash = dashDown && !this.prevDash;
		const pause = pauseDown && !this.prevPause;
		this.prevPulse = pulseDown;
		this.prevDash = dashDown;
		this.prevPause = pauseDown;
		this.pulseLatch = false;
		this.dashLatch = false;
		return {
			throttle,
			steer,
			pulse,
			dash,
			pause
		};
	}
	onKeyDown = (e) => {
		this.keys.add(e.code);
		if (BLOCK.has(e.code)) e.preventDefault();
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
	};
	clearHardware = () => {
		this.keys.clear();
	};
	onHide = () => {
		if (document.hidden) this.keys.clear();
	};
	readPad() {
		const out = {
			x: 0,
			y: 0,
			pulse: false,
			dash: false,
			pause: false
		};
		const nav = navigator;
		if (!nav.getGamepads) return out;
		let pads;
		try {
			pads = nav.getGamepads();
		} catch {
			return out;
		}
		for (const p of pads) {
			if (!p || p.mapping !== "standard") continue;
			const dz = radialDeadzone(p.axes[0] ?? 0, -(p.axes[1] ?? 0));
			out.x = dz.x;
			out.y = dz.y;
			out.pulse = !!p.buttons[0]?.pressed;
			out.dash = !!(p.buttons[1]?.pressed || p.buttons[5]?.pressed);
			out.pause = !!p.buttons[9]?.pressed;
			break;
		}
		return out;
	}
};
var ARENA_R = 1700;
var SOFT = 2.4;
var LIFE = 3.55;
var POOL_E = 36;
var POOL_B = 40;
var POOL_P = 320;
var POOL_F = 18;
var LACE_HIT = 8;
var NEWEST_SAFE = 36;
var noopFx = {
	cut() {},
	hit() {},
	dash() {},
	pulse() {},
	boom() {},
	wave() {}
};
var Spatial = class {
	buckets = /* @__PURE__ */ new Map();
	lists = [];
	n = 0;
	cell = 96;
	clear() {
		this.buckets.clear();
		this.n = 0;
	}
	take() {
		let list = this.lists[this.n];
		if (!list) {
			list = [];
			this.lists[this.n] = list;
		} else list.length = 0;
		this.n++;
		return list;
	}
	insert(i, x0, y0, x1, y1) {
		const s = this.cell;
		const xMin = Math.floor(Math.min(x0, x1) / s);
		const xMax = Math.floor(Math.max(x0, x1) / s);
		const yMin = Math.floor(Math.min(y0, y1) / s);
		const yMax = Math.floor(Math.max(y0, y1) / s);
		for (let y = yMin; y <= yMax; y++) for (let x = xMin; x <= xMax; x++) {
			const k = x * 73856093 ^ y * 19349663;
			let b = this.buckets.get(k);
			if (!b) {
				b = this.take();
				this.buckets.set(k, b);
			}
			b.push(i);
		}
	}
	query(x, y, r, out) {
		out.length = 0;
		const s = this.cell;
		const x0 = Math.floor((x - r) / s);
		const x1 = Math.floor((x + r) / s);
		const y0 = Math.floor((y - r) / s);
		const y1 = Math.floor((y + r) / s);
		for (let gy = y0; gy <= y1; gy++) for (let gx = x0; gx <= x1; gx++) {
			const b = this.buckets.get(gx * 73856093 ^ gy * 19349663);
			if (!b) continue;
			for (let i = 0; i < b.length; i++) out.push(b[i]);
		}
	}
};
var spatial = new Spatial();
var queryBuf = [];
var stamp = /* @__PURE__ */ new Int32Array(420);
var stampId = 1;
function blankEnemy() {
	return {
		alive: false,
		kind: "drift",
		x: 0,
		y: 0,
		yaw: 0,
		r: 14,
		hp: 1,
		maxHp: 1,
		state: 0,
		timer: 0,
		cool: 0,
		gen: 0,
		flash: 0,
		hurt: 0,
		dx: 1,
		dy: 0,
		nearMiss: false,
		pulseSeen: 0
	};
}
function makeParts() {
	return Array.from({ length: POOL_P }, () => ({
		alive: false,
		x: 0,
		y: 0,
		vx: 0,
		vy: 0,
		life: 0,
		max: 1,
		size: 2,
		hue: "glass"
	}));
}
function makeFloats() {
	return Array.from({ length: POOL_F }, () => ({
		alive: false,
		x: 0,
		y: 0,
		life: 0,
		max: 1,
		text: ""
	}));
}
function createState() {
	return {
		phase: "menu",
		t: 0,
		player: {
			x: 0,
			y: 0,
			yaw: 0,
			speed: 0,
			hp: 3,
			iframe: 0,
			flash: 0,
			dashT: 0,
			dashCd: 0,
			pulseCd: 0,
			radius: 13
		},
		enemies: Array.from({ length: POOL_E }, blankEnemy),
		bolts: Array.from({ length: POOL_B }, () => ({
			alive: false,
			x: 0,
			y: 0,
			vx: 0,
			vy: 0,
			life: 0
		})),
		lace: [],
		parts: makeParts(),
		floats: makeFloats(),
		laceX: 0,
		laceY: 0,
		laceInit: false,
		score: 0,
		best: 0,
		combo: 0,
		comboT: 0,
		wave: 1,
		toSpawn: 0,
		spawnT: 0,
		rest: 0,
		waveClear: false,
		banner: "",
		bannerT: 0,
		toast: "",
		toastT: 0,
		camX: 0,
		camY: 0,
		shakeX: 0,
		shakeY: 0,
		trauma: 0,
		zoom: 1,
		frameDt: 1 / 60,
		hitstop: 0,
		reduce: false,
		pulseId: 0,
		pulseR: 0,
		menuSpawn: .6,
		moteT: 0
	};
}
function killAll(s) {
	for (const e of s.enemies) e.alive = false;
	for (const b of s.bolts) b.alive = false;
	for (const p of s.parts) p.alive = false;
	for (const f of s.floats) f.alive = false;
	s.lace.length = 0;
	s.laceInit = false;
	s.pulseR = 0;
	s.hitstop = 0;
}
function beginMenu(s) {
	killAll(s);
	s.phase = "menu";
	s.t = 0;
	s.score = 0;
	s.combo = 0;
	s.banner = "";
	s.bannerT = 0;
	s.toast = "";
	s.toastT = 0;
	for (let i = 0; i < 96; i++) {
		const a = i * .21;
		const r = 28 + i * 3.1;
		s.lace.push({
			x: Math.cos(a) * r,
			y: Math.sin(a) * r,
			age: (96 - i) / 96 * 3.2
		});
	}
	const last = s.lace[s.lace.length - 1];
	s.player.x = last.x;
	s.player.y = last.y;
	s.player.yaw = tangentYaw(last.x, last.y);
	s.player.speed = 240;
	s.player.hp = 3;
	s.player.iframe = 1;
	s.player.dashT = 0;
	s.player.dashCd = 0;
	s.player.pulseCd = 0;
	s.laceX = last.x;
	s.laceY = last.y;
	s.laceInit = true;
	s.camX = last.x;
	s.camY = last.y;
	s.menuSpawn = .2;
	for (let i = 0; i < 4; i++) {
		const a = i / 4 * Math.PI * 2;
		spawnEnemy(s, "drift", Math.cos(a) * 180, Math.sin(a) * 180, 1);
	}
}
function tangentYaw(x, y) {
	const len = hypot(x, y) || 1;
	const tx = -y / len;
	const ty = x / len;
	return Math.atan2(-tx, ty);
}
function beginRun(s) {
	killAll(s);
	s.phase = "play";
	s.t = 0;
	s.player.x = 0;
	s.player.y = 0;
	s.player.yaw = 0;
	s.player.speed = 0;
	s.player.hp = 3;
	s.player.iframe = .6;
	s.player.flash = 0;
	s.player.dashT = 0;
	s.player.dashCd = 0;
	s.player.pulseCd = 0;
	s.score = 0;
	s.combo = 0;
	s.comboT = 0;
	s.wave = 1;
	s.toSpawn = waveCount(1);
	s.spawnT = 1.35;
	s.rest = 0;
	s.waveClear = false;
	s.banner = "Wave 1";
	s.bannerT = 1.7;
	s.toast = "Fresh wake cuts. Amber wake cuts you.";
	s.toastT = 5.2;
	s.camX = 0;
	s.camY = 0;
	s.trauma = 0;
	s.laceInit = false;
}
function waveCount(wave) {
	return 3 + wave;
}
function pickKind(wave) {
	const r = Math.random();
	if (wave >= 5 && r < .14) return "split";
	if (wave >= 3 && r < .36) return "spit";
	if (wave >= 2 && r < .6) return "lance";
	return "drift";
}
function spawnEnemy(s, kind, x, y, gen) {
	const e = s.enemies.find((en) => !en.alive);
	if (!e) return;
	e.alive = true;
	e.kind = kind;
	e.x = x;
	e.y = y;
	e.yaw = Math.random() * Math.PI * 2;
	e.hp = kind === "split" ? 4 : kind === "spit" ? 2 : 1;
	e.maxHp = e.hp;
	e.r = kind === "split" ? 26 : kind === "lance" ? 16 : 14;
	e.state = 0;
	e.timer = 0;
	e.cool = .6 + Math.random() * .6;
	e.gen = gen;
	e.flash = 0;
	e.hurt = 0;
	e.dx = 1;
	e.dy = 0;
	e.nearMiss = false;
	e.pulseSeen = 0;
}
function burst(s, x, y, hue, n) {
	let left = s.reduce ? Math.min(4, n) : n;
	for (const p of s.parts) {
		if (p.alive) continue;
		const a = Math.random() * Math.PI * 2;
		const sp = 30 + Math.random() * 240;
		p.alive = true;
		p.x = x;
		p.y = y;
		p.vx = Math.cos(a) * sp;
		p.vy = Math.sin(a) * sp;
		p.max = .28 + Math.random() * .42;
		p.life = p.max;
		p.size = 1.4 + Math.random() * 2.4;
		p.hue = hue;
		if (--left <= 0) break;
	}
}
function floater(s, x, y, text) {
	if (s.phase !== "play") return;
	const f = s.floats.find((fl) => !fl.alive);
	if (!f) return;
	f.alive = true;
	f.x = x;
	f.y = y;
	f.max = .8;
	f.life = .8;
	f.text = text;
}
function addScore(s, pts, x, y) {
	if (s.phase !== "play") return;
	s.score += pts;
	floater(s, x, y, `+${pts}`);
}
function killEnemy(s, e, fx) {
	e.alive = false;
	const hue = e.kind === "lance" ? "danger" : e.kind === "spit" ? "amber" : "tide";
	burst(s, e.x, e.y, hue, e.kind === "split" ? 22 : 12);
	if (e.kind === "split" && e.gen === 0) {
		spawnEnemy(s, "drift", e.x + 22, e.y + 8, 1);
		spawnEnemy(s, "drift", e.x - 22, e.y - 8, 1);
	}
	if (s.phase !== "play") {
		fx.cut();
		return;
	}
	s.combo += 1;
	s.comboT = 2.55;
	addScore(s, 70 + (s.combo - 1) * 28 + (e.kind === "lance" ? 40 : e.kind === "spit" ? 50 : e.kind === "split" ? 90 : 0), e.x, e.y);
	fx.cut();
	s.trauma = Math.min(1, s.trauma + (e.kind === "split" ? .45 : .22));
	if (e.kind === "split" || s.combo % 6 === 0) s.hitstop = Math.max(s.hitstop, .045);
}
function hurtPlayer(s, fx, kx, ky, label) {
	const p = s.player;
	if (s.phase !== "play" || p.iframe > 0 || p.dashT > 0) return;
	p.hp -= 1;
	p.iframe = 1.15;
	p.flash = .18;
	p.speed *= .35;
	p.x += kx;
	p.y += ky;
	s.combo = 0;
	s.comboT = 0;
	s.hitstop = .07;
	s.trauma = Math.min(1, s.trauma + .72);
	floater(s, p.x, p.y + 18, label);
	if (p.hp <= 0) {
		s.phase = "dead";
		burst(s, p.x, p.y, "glass", 36);
		burst(s, p.x, p.y, "amber", 16);
		fx.boom();
		if (s.score > s.best) s.best = s.score;
		s.banner = "Wake closed";
		s.bannerT = 2.4;
	} else fx.hit();
}
function damageEnemy(s, e, fx, force = false) {
	if (!e.alive) return;
	if (!force && e.hurt > 0) return;
	e.hp -= 1;
	e.hurt = .16;
	e.flash = .1;
	if (e.hp <= 0) killEnemy(s, e, fx);
	else fx.cut();
}
function fireBolt(s, x, y, tx, ty) {
	const b = s.bolts.find((bolt) => !bolt.alive);
	if (!b) return;
	const d = hypot(tx - x, ty - y) || 1;
	const sp = 175;
	b.alive = true;
	b.x = x;
	b.y = y;
	b.vx = (tx - x) / d * sp;
	b.vy = (ty - y) / d * sp;
	b.life = 3.4;
}
function contain(x, y, margin) {
	const d = hypot(x, y);
	const lim = ARENA_R - margin;
	if (d <= lim || d < 1e-4) return {
		x,
		y,
		hit: false,
		nx: 0,
		ny: 0
	};
	return {
		x: x / d * lim,
		y: y / d * lim,
		hit: true,
		nx: x / d,
		ny: y / d
	};
}
function compactLace(s) {
	const lace = s.lace;
	let w = 0;
	for (let i = 0; i < lace.length; i++) {
		const p = lace[i];
		if (p.age <= 3.55) lace[w++] = p;
	}
	lace.length = w;
}
function ageLace(s, dt) {
	const lace = s.lace;
	for (let i = 0; i < lace.length; i++) lace[i].age += dt;
	compactLace(s);
	if (s.lace.length > 420) s.lace.splice(0, s.lace.length - 420);
}
function emitLace(s) {
	const p = s.player;
	if (!s.laceInit) {
		s.laceInit = true;
		s.laceX = p.x;
		s.laceY = p.y;
		return;
	}
	const dx = p.x - s.laceX;
	const dy = p.y - s.laceY;
	const dist = hypot(dx, dy);
	const stepD = p.dashT > 0 ? 7 : 11;
	if (dist < stepD) return;
	const n = Math.min(5, Math.floor(dist / stepD));
	for (let i = 1; i <= n; i++) {
		const t = i * stepD / dist;
		const pt = {
			x: s.laceX + dx * t,
			y: s.laceY + dy * t,
			age: 0
		};
		s.lace.push(pt);
	}
	const used = n * stepD;
	s.laceX += dx * used / dist;
	s.laceY += dy * used / dist;
}
function rebuildHash(s) {
	spatial.clear();
	const lace = s.lace;
	for (let i = 0; i < lace.length - 1; i++) {
		const a = lace[i];
		const b = lace[i + 1];
		if (hypot(b.x - a.x, b.y - a.y) > 48) continue;
		spatial.insert(i, a.x, a.y, b.x, b.y);
	}
}
function uniqueQuery(x, y, r) {
	stampId++;
	if (stampId > 18e8) {
		stamp.fill(0);
		stampId = 1;
	}
	spatial.query(x, y, r, queryBuf);
	let w = 0;
	for (let i = 0; i < queryBuf.length; i++) {
		const idx = queryBuf[i];
		if (idx < 0 || idx >= 420) continue;
		if (stamp[idx] === stampId) continue;
		stamp[idx] = stampId;
		queryBuf[w++] = idx;
	}
	queryBuf.length = w;
	return queryBuf;
}
function steerTo(e, tx, ty, rate, dt) {
	const desired = Math.atan2(-(tx - e.x), ty - e.y);
	const d = clamp(angDiff(e.yaw, desired), -rate * dt, rate * dt);
	e.yaw += d;
}
function updateEnemy(s, e, dt) {
	const p = s.player;
	e.hurt = Math.max(0, e.hurt - dt);
	e.flash = Math.max(0, e.flash - dt);
	e.cool -= dt;
	const d = hypot(p.x - e.x, p.y - e.y);
	if (e.kind === "drift" || e.kind === "split" && e.gen > 0) {
		steerTo(e, p.x, p.y, 2.5, dt);
		const { fx, fy } = basis(e.yaw);
		const sp = 115 + Math.min(70, s.wave * 6);
		e.x += fx * sp * dt;
		e.y += fy * sp * dt;
	} else if (e.kind === "split") {
		steerTo(e, p.x, p.y, 1.5, dt);
		const { fx, fy } = basis(e.yaw);
		e.x += fx * 88 * dt;
		e.y += fy * 88 * dt;
	} else if (e.kind === "lance") {
		e.timer -= dt;
		if (e.state === 0) {
			steerTo(e, p.x, p.y, 2.2, dt);
			const { fx, fy } = basis(e.yaw);
			const sp = d > 360 ? 150 : 50;
			e.x += fx * sp * dt;
			e.y += fy * sp * dt;
			if (d < 430 && d > 160 && e.cool <= 0) {
				e.state = 1;
				e.timer = .56;
				e.dx = (p.x - e.x) / (d || 1);
				e.dy = (p.y - e.y) / (d || 1);
				e.nearMiss = false;
			}
		} else if (e.state === 1) {
			if (e.timer > .38) {
				const dd = hypot(p.x - e.x, p.y - e.y) || 1;
				e.dx = (p.x - e.x) / dd;
				e.dy = (p.y - e.y) / dd;
			}
			if (e.timer <= 0) {
				e.state = 2;
				e.timer = .32;
			}
		} else if (e.state === 2) {
			e.x += e.dx * 620 * dt;
			e.y += e.dy * 620 * dt;
			if (!e.nearMiss && d < 48 && d > p.radius + e.r + 2 && s.phase === "play") {
				e.nearMiss = true;
				addScore(s, 25, p.x, p.y + 24);
			}
			if (e.timer <= 0) {
				e.state = 3;
				e.timer = .48;
				e.cool = 1.15;
			}
		} else if (e.timer <= 0) e.state = 0;
	} else {
		const away = d < 230;
		let tx;
		let ty;
		if (away) {
			tx = e.x + (e.x - p.x);
			ty = e.y + (e.y - p.y);
		} else {
			const inv = d || 1;
			const px = -(p.y - e.y) / inv;
			const py = (p.x - e.x) / inv;
			tx = p.x + px * 300;
			ty = p.y + py * 300;
		}
		steerTo(e, tx, ty, 2.4, dt);
		const { fx, fy } = basis(e.yaw);
		e.x += fx * 108 * dt;
		e.y += fy * 108 * dt;
		if (e.cool <= 0 && d < 560 && s.phase === "play") {
			const nose = basis(e.yaw);
			fireBolt(s, e.x + nose.fx * e.r, e.y + nose.fy * e.r, p.x, p.y);
			e.cool = Math.max(1.15, 1.85 - s.wave * .06);
		}
	}
	const c = contain(e.x, e.y, e.r + 8);
	e.x = c.x;
	e.y = c.y;
}
function updateBolts(s, dt, fx) {
	const p = s.player;
	for (const b of s.bolts) {
		if (!b.alive) continue;
		b.life -= dt;
		b.x += b.vx * dt;
		b.y += b.vy * dt;
		if (b.life <= 0 || hypot(b.x, b.y) > 1700) {
			b.alive = false;
			continue;
		}
		const hits = uniqueQuery(b.x, b.y, 12);
		for (let i = 0; i < hits.length; i++) {
			const idx = hits[i];
			const a = s.lace[idx];
			const c = s.lace[idx + 1];
			if (!a || !c) continue;
			if (distPointSeg(b.x, b.y, a.x, a.y, c.x, c.y) < 10) {
				b.alive = false;
				burst(s, b.x, b.y, "amber", 5);
				addScore(s, 15, b.x, b.y);
				break;
			}
		}
		if (!b.alive) continue;
		if (hypot(b.x - p.x, b.y - p.y) < p.radius + 6) {
			b.alive = false;
			const d = hypot(b.vx, b.vy) || 1;
			hurtPlayer(s, fx, b.vx / d * 18, b.vy / d * 18, "BOLT");
		}
	}
}
function collideLace(s, fx) {
	const p = s.player;
	const lace = s.lace;
	const safeFrom = Math.max(0, lace.length - NEWEST_SAFE);
	for (const e of s.enemies) {
		if (!e.alive) continue;
		const hits = uniqueQuery(e.x, e.y, e.r + LACE_HIT + 4);
		for (let i = 0; i < hits.length; i++) {
			const idx = hits[i];
			const a = lace[idx];
			const b = lace[idx + 1];
			if (!a || !b) continue;
			if (distPointSeg(e.x, e.y, a.x, a.y, b.x, b.y) <= e.r + LACE_HIT) {
				damageEnemy(s, e, fx);
				break;
			}
		}
	}
	if (s.phase !== "play" || p.iframe > 0 || p.dashT > 0) return;
	const hits = uniqueQuery(p.x, p.y, p.radius + LACE_HIT + 4);
	for (let i = 0; i < hits.length; i++) {
		const idx = hits[i];
		if (idx >= safeFrom) continue;
		const a = lace[idx];
		const b = lace[idx + 1];
		if (!a || !b) continue;
		if ((a.age + b.age) * .5 < 2.4) continue;
		if (distPointSeg(p.x, p.y, a.x, a.y, b.x, b.y) <= p.radius + LACE_HIT - 1) {
			const mx = (a.x + b.x) * .5;
			const my = (a.y + b.y) * .5;
			const d = hypot(p.x - mx, p.y - my) || 1;
			hurtPlayer(s, fx, (p.x - mx) / d * 22, (p.y - my) / d * 22, "WAKE");
			break;
		}
	}
}
function collideBodies(s, fx) {
	const p = s.player;
	if (s.phase !== "play" || p.iframe > 0 || p.dashT > 0) return;
	for (const e of s.enemies) {
		if (!e.alive) continue;
		const d = hypot(e.x - p.x, e.y - p.y);
		if (d < e.r + p.radius) {
			const inv = d || 1;
			hurtPlayer(s, fx, (p.x - e.x) / inv * 26, (p.y - e.y) / inv * 26, "HIT");
			e.hurt = Math.max(e.hurt, .3);
			break;
		}
	}
}
function doPulse(s, fx) {
	const p = s.player;
	if (s.phase !== "play" || p.pulseCd > 0) return;
	p.pulseCd = 3.25;
	s.pulseId += 1;
	s.pulseR = 30;
	s.trauma = Math.min(1, s.trauma + .4);
	fx.pulse();
	const id = s.pulseId;
	for (const pt of s.lace) if (hypot(pt.x - p.x, pt.y - p.y) < 70) pt.age = 4.55;
	for (const e of s.enemies) {
		if (!e.alive) continue;
		if (hypot(e.x - p.x, e.y - p.y) < 78) {
			e.pulseSeen = id;
			damageEnemy(s, e, fx, true);
			const d = hypot(e.x - p.x, e.y - p.y) || 1;
			e.x += (e.x - p.x) / d * 40;
			e.y += (e.y - p.y) / d * 40;
		}
	}
}
function expandPulse(s, dt, fx) {
	if (s.pulseR <= 0) return;
	s.pulseR += dt * 860;
	if (s.pulseR > 280) {
		s.pulseR = 0;
		return;
	}
	const p = s.player;
	const id = s.pulseId;
	for (const pt of s.lace) if (hypot(pt.x - p.x, pt.y - p.y) < s.pulseR) pt.age = 4.55;
	for (const e of s.enemies) {
		if (!e.alive || e.pulseSeen === id) continue;
		const d = hypot(e.x - p.x, e.y - p.y);
		if (d <= s.pulseR && d >= s.pulseR - 36) {
			e.pulseSeen = id;
			damageEnemy(s, e, fx, true);
			const inv = d || 1;
			e.x += (e.x - p.x) / inv * 28;
			e.y += (e.y - p.y) / inv * 28;
		}
	}
	for (const b of s.bolts) {
		if (!b.alive) continue;
		if (hypot(b.x - p.x, b.y - p.y) < s.pulseR) b.alive = false;
	}
	compactLace(s);
}
function updateDirector(s, dt, fx) {
	if (s.phase === "menu") {
		s.menuSpawn -= dt;
		if (s.menuSpawn <= 0) {
			s.menuSpawn = 1.3;
			let alive = 0;
			for (const e of s.enemies) if (e.alive) alive++;
			if (alive < 4) {
				const a = Math.random() * Math.PI * 2;
				spawnEnemy(s, Math.random() < .25 ? "lance" : "drift", s.player.x + Math.cos(a) * 260, s.player.y + Math.sin(a) * 260, 1);
			}
		}
		return;
	}
	if (s.phase !== "play") return;
	if (s.waveClear) {
		s.rest -= dt;
		if (s.rest <= 0) {
			s.wave += 1;
			s.toSpawn = waveCount(s.wave);
			s.spawnT = .45;
			s.waveClear = false;
			s.banner = `Wave ${s.wave}`;
			s.bannerT = 1.6;
		}
		return;
	}
	if (s.toSpawn > 0) {
		s.spawnT -= dt;
		if (s.spawnT <= 0) {
			const a = Math.random() * Math.PI * 2;
			const dist = 480 + Math.random() * 180;
			let x = s.player.x + Math.cos(a) * dist;
			let y = s.player.y + Math.sin(a) * dist;
			const c = contain(x, y, 80);
			x = c.x;
			y = c.y;
			spawnEnemy(s, pickKind(s.wave), x, y, 0);
			s.toSpawn -= 1;
			s.spawnT = Math.max(.38, .92 - s.wave * .04);
		}
		return;
	}
	let alive = 0;
	for (const e of s.enemies) if (e.alive) alive++;
	if (alive === 0) {
		s.waveClear = true;
		s.rest = 2.05;
		const bonus = 140 + s.wave * 45;
		s.score += bonus;
		floater(s, s.player.x, s.player.y + 30, `WAVE +${bonus}`);
		fx.wave();
	}
}
function updateParts(s, dt) {
	for (const p of s.parts) {
		if (!p.alive) continue;
		p.life -= dt;
		if (p.life <= 0) {
			p.alive = false;
			continue;
		}
		p.x += p.vx * dt;
		p.y += p.vy * dt;
		const drag = Math.exp(-1.6 * dt);
		p.vx *= drag;
		p.vy *= drag;
	}
	for (const f of s.floats) {
		if (!f.alive) continue;
		f.life -= dt;
		if (f.life <= 0) f.alive = false;
		else f.y += 28 * dt;
	}
	s.bannerT = Math.max(0, s.bannerT - dt);
	s.toastT = Math.max(0, s.toastT - dt);
	s.moteT -= dt;
	if (s.moteT <= 0) {
		s.moteT = .22;
		const a = Math.random() * Math.PI * 2;
		const rad = Math.random() * 200;
		burst(s, s.player.x + Math.cos(a) * rad, s.player.y + Math.sin(a) * rad, "glass", 1);
	}
}
function step(s, input, dt, fx = noopFx) {
	s.t += dt;
	const p = s.player;
	p.iframe = Math.max(0, p.iframe - dt);
	p.flash = Math.max(0, p.flash - dt);
	p.dashCd = Math.max(0, p.dashCd - dt);
	p.pulseCd = Math.max(0, p.pulseCd - dt);
	s.trauma = Math.max(0, s.trauma - dt * 1.55);
	s.comboT = Math.max(0, s.comboT - dt);
	if (s.comboT <= 0) s.combo = 0;
	if (s.phase === "pause") return;
	if (s.hitstop > 0 && s.phase === "play") {
		s.hitstop -= dt;
		updateParts(s, dt * .25);
		return;
	}
	if (s.phase === "dead") {
		updateParts(s, dt);
		expandPulse(s, dt, fx);
		return;
	}
	if (s.phase === "menu") {
		p.yaw += (.65 + Math.sin(s.t * .85) * 1.05) * dt;
		p.speed = 235 + Math.sin(s.t * .45) * 30;
		p.iframe = 1;
	} else {
		if (input.dash && p.dashCd <= 0 && p.dashT <= 0) {
			p.dashT = .16;
			p.dashCd = 1.15;
			fx.dash();
			s.trauma = Math.min(1, s.trauma + .18);
		}
		if (input.pulse) doPulse(s, fx);
		if (p.dashT > 0) {
			p.dashT -= dt;
			p.speed = 730;
			p.iframe = Math.max(p.iframe, .05);
		} else if (input.throttle > .05) {
			const target = 360 * input.throttle;
			p.speed += (target - p.speed) * (1 - Math.exp(-3.4 * dt));
		} else if (input.throttle < -.05) p.speed += (-130 - p.speed) * (1 - Math.exp(-4.2 * dt));
		else p.speed *= Math.exp(-1.25 * dt);
		const spf = clamp(Math.abs(p.speed) / 80, .55, 1);
		const reverse = p.speed >= -8 ? 1 : -1;
		p.yaw += input.steer * 2.75 * spf * reverse * dt;
	}
	const head = basis(p.yaw);
	p.x += head.fx * p.speed * dt;
	p.y += head.fy * p.speed * dt;
	const wall = contain(p.x, p.y, 22);
	if (wall.hit) {
		p.x = wall.x;
		p.y = wall.y;
		if (head.fx * wall.nx + head.fy * wall.ny > 0 && p.speed > 0) p.speed *= .45;
	}
	emitLace(s);
	ageLace(s, dt);
	expandPulse(s, dt, fx);
	for (const e of s.enemies) if (e.alive) updateEnemy(s, e, dt);
	rebuildHash(s);
	updateBolts(s, dt, fx);
	collideLace(s, fx);
	collideBodies(s, fx);
	updateDirector(s, dt, fx);
	updateParts(s, dt);
}
var INK = "#0a0a0b";
var TIDE = "46, 201, 182";
var AMBER = "212, 148, 74";
var DANGER = "225, 90, 74";
var GLASS = "244, 244, 245";
var nebula = null;
var stars = null;
function ensureBg() {
	if (!nebula) {
		const c = document.createElement("canvas");
		c.width = 640;
		c.height = 640;
		const g = c.getContext("2d");
		if (!g) return;
		g.fillStyle = INK;
		g.fillRect(0, 0, 640, 640);
		const blobs = [
			{
				x: 160,
				y: 460,
				r: 280,
				rgb: TIDE
			},
			{
				x: 500,
				y: 180,
				r: 300,
				rgb: AMBER
			},
			{
				x: 320,
				y: 320,
				r: 180,
				rgb: GLASS
			}
		];
		for (const b of blobs) {
			const rad = g.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
			rad.addColorStop(0, `rgba(${b.rgb}, 0.2)`);
			rad.addColorStop(1, "rgba(0,0,0,0)");
			g.fillStyle = rad;
			g.fillRect(0, 0, 640, 640);
		}
		nebula = c;
	}
	if (!stars) {
		stars = /* @__PURE__ */ new Float32Array(480);
		for (let i = 0; i < 160; i++) {
			stars[i * 3] = Math.random();
			stars[i * 3 + 1] = Math.random();
			stars[i * 3 + 2] = .3 + Math.random() * .7;
		}
	}
}
function applyCam(ctx, s, w, h) {
	ctx.translate(w / 2 + s.shakeX, h / 2 + s.shakeY);
	ctx.scale(s.zoom, -s.zoom);
	ctx.translate(-s.camX, -s.camY);
}
function hueRgb(h) {
	if (h === "tide") return TIDE;
	if (h === "amber") return AMBER;
	if (h === "danger") return DANGER;
	return GLASS;
}
function drawRibbon(ctx, s, glow) {
	const lace = s.lace;
	for (let i = 0; i < lace.length - 1; i++) {
		const a = lace[i];
		const b = lace[i + 1];
		const dx = b.x - a.x;
		const dy = b.y - a.y;
		const len = Math.hypot(dx, dy);
		if (len < .001 || len > 48) continue;
		const nx = -dy / len;
		const ny = dx / len;
		const age = (a.age + b.age) * .5;
		const u = Math.min(1, age / LIFE);
		const hard = age >= SOFT;
		const alpha = (glow ? .5 : .92) * (1 - u * .55);
		const hw = (glow ? 18 : 5.2) * (hard ? .8 : 1);
		ctx.beginPath();
		ctx.moveTo(a.x + nx * hw, a.y + ny * hw);
		ctx.lineTo(b.x + nx * hw, b.y + ny * hw);
		ctx.lineTo(b.x - nx * hw, b.y - ny * hw);
		ctx.lineTo(a.x - nx * hw, a.y - ny * hw);
		ctx.closePath();
		ctx.fillStyle = hard ? `rgba(${AMBER}, ${alpha})` : `rgba(${TIDE}, ${alpha})`;
		ctx.fill();
	}
	if (glow) return;
	ctx.lineWidth = 1.6 / Math.max(.4, s.zoom);
	ctx.lineCap = "round";
	for (let i = 0; i < lace.length - 1; i++) {
		const a = lace[i];
		const b = lace[i + 1];
		if (a.age > 2.04) continue;
		const len = Math.hypot(b.x - a.x, b.y - a.y);
		if (len < .001 || len > 48) continue;
		ctx.beginPath();
		ctx.moveTo(a.x, a.y);
		ctx.lineTo(b.x, b.y);
		ctx.strokeStyle = `rgba(${GLASS}, ${.8 * (1 - a.age / SOFT)})`;
		ctx.stroke();
	}
}
function poly(ctx, pts) {
	ctx.beginPath();
	ctx.moveTo(pts[0], pts[1]);
	for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
	ctx.closePath();
}
function drawEnemy(ctx, e, zoom, glow) {
	const { fx, fy, rx, ry } = basis(e.yaw);
	const rgb = e.kind === "lance" ? DANGER : e.kind === "spit" ? AMBER : e.kind === "split" ? GLASS : TIDE;
	if (glow) {
		ctx.fillStyle = `rgba(${rgb}, 0.85)`;
		ctx.beginPath();
		ctx.arc(e.x, e.y, e.r * 1.35, 0, Math.PI * 2);
		ctx.fill();
		return;
	}
	ctx.fillStyle = e.flash > 0 ? `rgba(${GLASS}, 0.95)` : `rgba(${rgb}, 0.95)`;
	if (e.kind === "spit") {
		ctx.beginPath();
		for (let i = 0; i < 6; i++) {
			const a = e.yaw + i / 6 * Math.PI * 2;
			const rad = e.r * (i % 2 === 0 ? 1 : .72);
			const x = e.x + Math.cos(a) * rad;
			const y = e.y + Math.sin(a) * rad;
			if (i === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		}
		ctx.closePath();
		ctx.fill();
	} else if (e.kind === "split") {
		ctx.beginPath();
		ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = `rgba(${TIDE}, 0.9)`;
		poly(ctx, [
			e.x + fx * e.r * .7,
			e.y + fy * e.r * .7,
			e.x - fx * e.r * .45 + rx * e.r * .45,
			e.y - fy * e.r * .45 + ry * e.r * .45,
			e.x - fx * e.r * .45 - rx * e.r * .45,
			e.y - fy * e.r * .45 - ry * e.r * .45
		]);
		ctx.fill();
	} else {
		const nose = e.kind === "lance" ? e.r * 1.7 : e.r * 1.35;
		const tail = e.r * .9;
		const wide = e.r * .72;
		poly(ctx, [
			e.x + fx * nose,
			e.y + fy * nose,
			e.x - fx * tail + rx * wide,
			e.y - fy * tail + ry * wide,
			e.x - fx * tail * .4,
			e.y - fy * tail * .4,
			e.x - fx * tail - rx * wide,
			e.y - fy * tail - ry * wide
		]);
		ctx.fill();
	}
	if (e.kind === "lance" && e.state === 1) {
		ctx.strokeStyle = `rgba(${DANGER}, ${.45 + .4 * Math.sin(e.timer * 30)})`;
		ctx.lineWidth = 2 / zoom;
		ctx.setLineDash([10 / zoom, 7 / zoom]);
		ctx.beginPath();
		ctx.moveTo(e.x, e.y);
		ctx.lineTo(e.x + e.dx * 220, e.y + e.dy * 220);
		ctx.stroke();
		ctx.setLineDash([]);
	}
	if (e.maxHp > 1 && e.hp < e.maxHp) {
		const ww = e.r * 1.6;
		ctx.fillStyle = `rgba(${GLASS}, 0.25)`;
		ctx.fillRect(e.x - ww / 2, e.y + e.r + 8, ww, 3 / zoom);
		ctx.fillStyle = `rgba(${GLASS}, 0.9)`;
		ctx.fillRect(e.x - ww / 2, e.y + e.r + 8, ww * (e.hp / e.maxHp), 3 / zoom);
	}
}
function drawShip(ctx, s, glow) {
	const p = s.player;
	if (p.hp <= 0 && s.phase === "dead") return;
	if (!glow && p.iframe > 0 && Math.sin(s.t * 46) > .2 && s.phase === "play") return;
	const { fx, fy, rx, ry } = basis(p.yaw);
	const stretch = 1 + Math.min(1, Math.abs(p.speed) / 420) * .38;
	const nose = 28 * stretch;
	const tail = 16 / Math.sqrt(stretch);
	const wide = 12 / Math.sqrt(stretch);
	if (glow) {
		ctx.fillStyle = `rgba(${TIDE}, 0.9)`;
		ctx.beginPath();
		ctx.arc(p.x, p.y, 20, 0, Math.PI * 2);
		ctx.fill();
		return;
	}
	ctx.fillStyle = `rgba(${GLASS}, 0.96)`;
	poly(ctx, [
		p.x + fx * nose,
		p.y + fy * nose,
		p.x - fx * tail + rx * wide,
		p.y - fy * tail + ry * wide,
		p.x - fx * tail * .45,
		p.y - fy * tail * .45,
		p.x - fx * tail - rx * wide,
		p.y - fy * tail - ry * wide
	]);
	ctx.fill();
	ctx.fillStyle = `rgba(${TIDE}, 0.95)`;
	poly(ctx, [
		p.x + fx * nose * .55,
		p.y + fy * nose * .55,
		p.x - fx * 4 + rx * 3.2,
		p.y - fy * 4 + ry * 3.2,
		p.x - fx * 4 - rx * 3.2,
		p.y - fy * 4 - ry * 3.2
	]);
	ctx.fill();
}
function drawFloor(ctx, s) {
	const zoom = Math.max(.35, s.zoom);
	ctx.beginPath();
	ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(8, 8, 10, 0.78)";
	ctx.fill();
	ctx.save();
	ctx.clip();
	const reach = Math.max(1400, 900 / zoom);
	const minX = s.camX - reach;
	const maxX = s.camX + reach;
	const minY = s.camY - reach;
	const maxY = s.camY + reach;
	const gap = 96;
	ctx.lineWidth = 1 / zoom;
	ctx.strokeStyle = "rgba(244, 244, 245, 0.045)";
	ctx.beginPath();
	for (let x = Math.floor(minX / gap) * gap; x <= maxX; x += gap) {
		ctx.moveTo(x, minY);
		ctx.lineTo(x, maxY);
	}
	for (let y = Math.floor(minY / gap) * gap; y <= maxY; y += gap) {
		ctx.moveTo(minX, y);
		ctx.lineTo(maxX, y);
	}
	ctx.stroke();
	ctx.restore();
	ctx.lineWidth = 1.25 / zoom;
	ctx.strokeStyle = "rgba(244, 244, 245, 0.07)";
	for (const r of [
		160,
		320,
		520,
		780,
		1100,
		1450
	]) {
		ctx.beginPath();
		ctx.arc(0, 0, r, 0, Math.PI * 2);
		ctx.stroke();
	}
	ctx.lineWidth = 2 / zoom;
	ctx.strokeStyle = "rgba(244, 244, 245, 0.28)";
	ctx.beginPath();
	ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
	ctx.stroke();
}
function drawActors(ctx, s, glow) {
	drawRibbon(ctx, s, glow);
	for (const e of s.enemies) if (e.alive) drawEnemy(ctx, e, s.zoom, glow);
	for (const b of s.bolts) {
		if (!b.alive) continue;
		ctx.fillStyle = glow ? `rgba(${AMBER}, 0.9)` : `rgba(${GLASS}, 0.95)`;
		ctx.beginPath();
		ctx.arc(b.x, b.y, glow ? 8 : 3.4, 0, Math.PI * 2);
		ctx.fill();
	}
	if (s.pulseR > 0) {
		ctx.strokeStyle = glow ? `rgba(${GLASS}, 0.7)` : `rgba(${TIDE}, 0.85)`;
		ctx.lineWidth = (glow ? 10 : 2.2) / Math.max(.4, s.zoom);
		ctx.beginPath();
		ctx.arc(s.player.x, s.player.y, s.pulseR, 0, Math.PI * 2);
		ctx.stroke();
	}
	drawShip(ctx, s, glow);
	if (glow) return;
	for (const p of s.parts) {
		if (!p.alive) continue;
		const a = Math.max(0, p.life / p.max);
		ctx.fillStyle = `rgba(${hueRgb(p.hue)}, ${a})`;
		ctx.fillRect(p.x - p.size * .5, p.y - p.size * .5, p.size, p.size);
	}
}
function project(s, x, y, w, h) {
	return {
		x: (x - s.camX) * s.zoom + w / 2 + s.shakeX,
		y: (s.camY - y) * s.zoom + h / 2 + s.shakeY
	};
}
function render(view, glow, s, cssW, cssH, dpr) {
	ensureBg();
	const dt = Math.max(.001, s.frameDt);
	const head = basis(s.player.yaw);
	const look = s.phase === "menu" ? 40 : 120;
	const tx = s.player.x + head.fx * look;
	const ty = s.player.y + head.fy * look;
	const k = 1 - Math.exp(-4.6 * dt);
	s.camX += (tx - s.camX) * k;
	s.camY += (ty - s.camY) * k;
	s.zoom = Math.min(cssW, cssH) / 680;
	const mag = s.reduce ? 0 : s.trauma * s.trauma;
	s.shakeX = Math.sin(s.t * 41.2) * 18 * mag;
	s.shakeY = Math.sin(s.t * 33.4 + 1.7) * 12 * mag;
	glow.setTransform(1, 0, 0, 1, 0, 0);
	glow.clearRect(0, 0, glow.canvas.width, glow.canvas.height);
	glow.setTransform(dpr, 0, 0, dpr, 0, 0);
	glow.save();
	applyCam(glow, s, cssW, cssH);
	drawActors(glow, s, true);
	glow.restore();
	view.setTransform(dpr, 0, 0, dpr, 0, 0);
	view.fillStyle = INK;
	view.fillRect(0, 0, cssW, cssH);
	if (nebula) {
		const nx = -s.camX * .06 % cssW - cssW * .15;
		const ny = s.camY * .06 % cssH - cssH * .15;
		view.globalAlpha = .9;
		view.drawImage(nebula, nx, ny, cssW * 1.4, cssH * 1.4);
		view.globalAlpha = 1;
	}
	if (stars) {
		view.fillStyle = `rgba(${GLASS}, 0.8)`;
		for (let i = 0; i < 160; i++) {
			const sx = ((stars[i * 3] * cssW * 1.5 - s.camX * .12) % (cssW * 1.5) + cssW * 1.5) % (cssW * 1.5) - cssW * .25;
			const sy = ((stars[i * 3 + 1] * cssH * 1.5 + s.camY * .12) % (cssH * 1.5) + cssH * 1.5) % (cssH * 1.5) - cssH * .25;
			const r = stars[i * 3 + 2];
			view.globalAlpha = .25 + r * .55;
			view.fillRect(sx, sy, r > .8 ? 2 : 1.2, r > .8 ? 2 : 1.2);
		}
		view.globalAlpha = 1;
	}
	view.save();
	applyCam(view, s, cssW, cssH);
	drawFloor(view, s);
	view.restore();
	view.save();
	view.filter = s.reduce ? "none" : "blur(16px)";
	view.globalCompositeOperation = "lighter";
	view.drawImage(glow.canvas, 0, 0, cssW, cssH);
	view.restore();
	view.save();
	applyCam(view, s, cssW, cssH);
	drawActors(view, s, false);
	view.restore();
	const vig = view.createRadialGradient(cssW / 2, cssH / 2, Math.min(cssW, cssH) * .28, cssW / 2, cssH / 2, Math.max(cssW, cssH) * .72);
	vig.addColorStop(0, "rgba(0,0,0,0)");
	vig.addColorStop(1, "rgba(0,0,0,0.58)");
	view.fillStyle = vig;
	view.fillRect(0, 0, cssW, cssH);
	if (s.player.flash > 0 && !s.reduce) {
		view.fillStyle = `rgba(244,244,245,${s.player.flash * .35})`;
		view.fillRect(0, 0, cssW, cssH);
	}
	view.textAlign = "center";
	view.font = "600 13px Outfit, sans-serif";
	for (const f of s.floats) {
		if (!f.alive) continue;
		const p = project(s, f.x, f.y, cssW, cssH);
		view.globalAlpha = Math.max(0, f.life / f.max);
		view.fillStyle = "#f4f4f5";
		view.fillText(f.text, p.x, p.y);
	}
	view.globalAlpha = 1;
	if (s.bannerT > 0 && s.banner && s.phase !== "menu") {
		view.globalAlpha = Math.min(1, s.bannerT);
		view.font = "600 28px Syne, sans-serif";
		view.fillStyle = "#f4f4f5";
		view.fillText(s.banner, cssW / 2, 86);
		view.globalAlpha = 1;
	}
}
var STEP = 1 / 60;
var SAVE_KEY = "lace.v1";
function loadSave() {
	const blank = {
		v: 1,
		best: 0,
		mute: false,
		shake: true,
		volume: .8
	};
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return blank;
		const p = JSON.parse(raw);
		return {
			v: 1,
			best: typeof p.best === "number" ? p.best : 0,
			mute: !!p.mute,
			shake: p.shake !== false,
			volume: typeof p.volume === "number" ? p.volume : .8
		};
	} catch {
		return blank;
	}
}
var Engine = class {
	state;
	input;
	audio;
	hooks;
	canvas;
	glow;
	viewCtx;
	glowCtx;
	raf = 0;
	stopped = false;
	last = 0;
	acc = 0;
	sample = {
		throttle: 0,
		steer: 0,
		pulse: false,
		dash: false,
		pause: false
	};
	lastPhase = "menu";
	ro = null;
	shakeOn = true;
	reduce;
	save;
	constructor(canvas, hooks) {
		this.canvas = canvas;
		this.hooks = hooks;
		this.state = createState();
		this.save = loadSave();
		this.state.best = this.save.best;
		this.shakeOn = this.save.shake;
		this.reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.state.reduce = this.reduce || !this.shakeOn;
		this.input = new Input();
		this.audio = new AudioBus();
		this.audio.muted = this.save.mute;
		this.audio.volume = this.save.volume;
		const view = canvas.getContext("2d", { alpha: false });
		if (!view) throw new Error("Canvas 2D is unavailable");
		this.viewCtx = view;
		this.glow = document.createElement("canvas");
		const glow = this.glow.getContext("2d", { alpha: true });
		if (!glow) throw new Error("Glow buffer is unavailable");
		this.glowCtx = glow;
		beginMenu(this.state);
		this.lastPhase = "menu";
		this.ro = new ResizeObserver(() => this.paint(0));
		this.ro.observe(canvas);
		const vis = () => {
			if (document.visibilityState === "visible") this.audio.resume();
		};
		document.addEventListener("visibilitychange", vis);
		this.onVis = vis;
		canvas.addEventListener("pointerdown", this.onPointer);
		window.__controlsTest = {
			getYaw: () => this.state.player.yaw,
			getSpeed: () => this.state.phase === "play" ? this.state.player.speed : 0,
			setKeys: (codes) => this.input.setKeys(codes),
			setSteer: (v) => this.input.setSteer(v)
		};
		this.raf = requestAnimationFrame(this.loop);
		hooks.onSave(this.save);
	}
	onVis = () => {};
	onPointer = (e) => {
		if (e.button !== 0) return;
		if (this.state.phase === "play") this.input.latchPulse();
	};
	destroy() {
		this.stopped = true;
		cancelAnimationFrame(this.raf);
		this.ro?.disconnect();
		this.input.destroy();
		this.audio.dispose();
		this.canvas.removeEventListener("pointerdown", this.onPointer);
		document.removeEventListener("visibilitychange", this.onVis);
		if (window.__controlsTest?.getYaw && window.__controlsTest.getYaw() === this.state.player.yaw) delete window.__controlsTest;
	}
	startRun() {
		this.audio.unlock();
		this.audio.startMusic();
		beginRun(this.state);
		this.state.reduce = this.reduce || !this.shakeOn;
		this.state.best = this.save.best;
		this.lastPhase = "play";
		this.hooks.onPhase("play");
	}
	togglePause() {
		if (this.state.phase === "play") this.state.phase = "pause";
		else if (this.state.phase === "pause") this.state.phase = "play";
		else return;
		this.lastPhase = this.state.phase;
		this.hooks.onPhase(this.state.phase);
	}
	toggleMute() {
		this.audio.unlock();
		this.save.mute = !this.save.mute;
		this.audio.setMuted(this.save.mute);
		this.persist();
		return this.save.mute;
	}
	setVolume(unit) {
		this.audio.unlock();
		this.save.volume = unit;
		this.audio.setVolume(unit);
		this.persist();
	}
	setShake(on) {
		this.shakeOn = on;
		this.save.shake = on;
		this.state.reduce = this.reduce || !on;
		this.persist();
	}
	stick(x, y) {
		this.input.setStick(x, y);
	}
	pressDash() {
		this.input.latchDash();
	}
	pressPulse() {
		this.input.latchPulse();
	}
	persist() {
		if (this.state.best > this.save.best) this.save.best = this.state.best;
		try {
			localStorage.setItem(SAVE_KEY, JSON.stringify(this.save));
		} catch {}
		this.hooks.onSave(this.save);
	}
	fx() {
		return {
			cut: () => this.audio.cut(),
			hit: () => this.audio.hit(),
			dash: () => this.audio.dash(),
			pulse: () => this.audio.pulse(),
			boom: () => this.audio.boom(),
			wave: () => this.audio.wave()
		};
	}
	loop = (now) => {
		if (this.stopped) return;
		const dt = this.last === 0 ? STEP : Math.min(.1, (now - this.last) / 1e3);
		this.last = now;
		this.sample = this.input.sample();
		if (this.sample.pause) this.togglePause();
		if (this.state.phase !== "pause") {
			this.acc += dt;
			let n = 0;
			const effects = this.fx();
			let first = true;
			while (this.acc >= STEP && n < 5) {
				const edge = first ? this.sample : {
					...this.sample,
					pulse: false,
					dash: false,
					pause: false
				};
				step(this.state, edge, STEP, effects);
				first = false;
				this.acc -= STEP;
				n++;
			}
		} else this.acc = 0;
		if (this.state.phase === "dead" && this.state.best > this.save.best) {
			this.save.best = this.state.best;
			this.persist();
		} else if (this.state.best > this.save.best) this.save.best = this.state.best;
		if (this.state.phase !== this.lastPhase) {
			this.lastPhase = this.state.phase;
			this.hooks.onPhase(this.state.phase);
			if (this.state.phase === "dead") this.persist();
		}
		this.paint(dt);
		this.hooks.onFrame(this.hud());
		if (!this.stopped) this.raf = requestAnimationFrame(this.loop);
	};
	hud() {
		const p = this.state.player;
		const s = this.state;
		return {
			phase: s.phase,
			score: s.score,
			best: Math.max(s.best, this.save.best),
			combo: s.combo,
			wave: s.wave,
			hp: p.hp,
			maxHp: 3,
			pulse: p.pulseCd <= 0 ? 1 : 1 - p.pulseCd / 3.25,
			dash: p.dashCd <= 0 ? 1 : 1 - p.dashCd / 1.15,
			toast: s.toastT > 0 ? s.toast : "",
			banner: s.bannerT > 0 ? s.banner : ""
		};
	}
	paint(dt) {
		const canvas = this.canvas;
		const cssW = canvas.clientWidth;
		const cssH = canvas.clientHeight;
		if (cssW < 2 || cssH < 2) return;
		const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
		const pw = Math.max(1, Math.round(cssW * dpr));
		const ph = Math.max(1, Math.round(cssH * dpr));
		if (canvas.width !== pw || canvas.height !== ph) {
			canvas.width = pw;
			canvas.height = ph;
		}
		if (this.glow.width !== pw || this.glow.height !== ph) {
			this.glow.width = pw;
			this.glow.height = ph;
		}
		this.state.frameDt = dt || STEP;
		this.state.reduce = this.reduce || !this.shakeOn;
		render(this.viewCtx, this.glowCtx, this.state, cssW, cssH, dpr);
	}
};
function fmt(n) {
	return Math.max(0, Math.floor(n)).toLocaleString("en-US");
}
function LaceApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const scoreRef = (0, import_react.useRef)(null);
	const bestRef = (0, import_react.useRef)(null);
	const comboRef = (0, import_react.useRef)(null);
	const waveRef = (0, import_react.useRef)(null);
	const toastRef = (0, import_react.useRef)(null);
	const pulseRef = (0, import_react.useRef)(null);
	const dashRef = (0, import_react.useRef)(null);
	const pips = (0, import_react.useRef)([]);
	const [phase, setPhase] = (0, import_react.useState)("menu");
	const [save, setSave] = (0, import_react.useState)({
		v: 1,
		best: 0,
		mute: false,
		shake: true,
		volume: .8
	});
	const [touch, setTouch] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const engine = new Engine(canvas, {
			onPhase: setPhase,
			onSave: setSave,
			onFrame: (h) => {
				const score = fmt(h.score);
				if (scoreRef.current && scoreRef.current.textContent !== score) scoreRef.current.textContent = score;
				const best = fmt(h.best);
				if (bestRef.current && bestRef.current.textContent !== best) bestRef.current.textContent = best;
				if (comboRef.current) {
					const label = h.combo > 1 ? `x${h.combo}` : "";
					if (comboRef.current.textContent !== label) comboRef.current.textContent = label;
				}
				if (waveRef.current) {
					const label = `Wave ${h.wave}`;
					if (waveRef.current.textContent !== label) waveRef.current.textContent = label;
				}
				if (toastRef.current && toastRef.current.textContent !== h.toast) toastRef.current.textContent = h.toast;
				if (pulseRef.current) pulseRef.current.style.transform = `scaleX(${h.pulse})`;
				if (dashRef.current) dashRef.current.style.transform = `scaleX(${h.dash})`;
				for (let i = 0; i < 3; i++) {
					const pip = pips.current[i];
					if (!pip) continue;
					const on = i < h.hp;
					pip.dataset.on = on ? "1" : "0";
					pip.style.background = on ? h.hp === 1 ? "var(--color-danger)" : "var(--color-glass)" : "var(--color-line)";
				}
			}
		});
		engineRef.current = engine;
		const syncTouch = () => {
			const coarse = window.matchMedia("(pointer: coarse)").matches;
			setTouch(coarse || window.innerWidth < 860);
		};
		syncTouch();
		window.addEventListener("resize", syncTouch);
		return () => {
			window.removeEventListener("resize", syncTouch);
			engine.destroy();
			engineRef.current = null;
		};
	}, []);
	const playing = phase === "play" || phase === "pause" || phase === "dead";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-ink text-glass",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				"aria-label": "Lace, a glass-wake skiff"
			}),
			phase === "play" || phase === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-4 p-4 pt-[max(1rem,env(safe-area-inset-top))] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-subtle uppercase",
						children: "Score"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl leading-none font-semibold tabular-nums",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							ref: scoreRef,
							children: "0"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-tide tabular-nums",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { ref: comboRef })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						ref: toastRef,
						className: "mt-2 max-w-xs text-sm text-muted"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							ref: waveRef,
							className: "font-display text-lg font-semibold",
							children: "Wave 1"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted tabular-nums",
							children: ["Best ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								ref: bestRef,
								children: fmt(save.best)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex items-center justify-end gap-1.5",
							"aria-label": "Hull",
							children: [
								0,
								1,
								2
							].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								ref: (el) => {
									pips.current[i] = el;
								},
								className: "h-2 w-7 rounded-full bg-glass"
							}, i))
						})
					]
				})]
			}) : null,
			phase === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between gap-4 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-36 flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Pulse",
							barRef: pulseRef
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Dash",
							barRef: dashRef
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-xs text-subtle sm:block",
							children: "Space pulse · Shift dash"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-control border border-line bg-elev text-glass",
						"aria-label": save.mute ? "Unmute" : "Mute",
						onClick: () => engineRef.current?.toggleMute(),
						children: save.mute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-control border border-line bg-elev text-glass",
						"aria-label": "Pause",
						onClick: () => engineRef.current?.togglePause(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
					})]
				})]
			}) : null,
			phase === "play" && touch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TouchLayer, {
				onStick: (x, y) => engineRef.current?.stick(x, y),
				onDash: () => engineRef.current?.pressDash(),
				onPulse: () => engineRef.current?.pressPulse()
			}) : null,
			phase === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-end p-4 sm:items-center sm:p-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rise max-h-[78dvh] w-full max-w-md overflow-auto rounded-panel border border-line bg-elev p-6 sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-subtle uppercase",
							children: "Filament trial"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display mt-2 text-5xl leading-none font-semibold tracking-tight",
							children: "Lace"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-sm text-sm leading-relaxed text-muted",
							children: "You weave a wake of glass. Fresh glass severs. Once it turns amber, it severs you."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							id: "start-run",
							type: "button",
							className: "mt-6 h-12 w-full rounded-control bg-glass text-base font-semibold text-ink transition-opacity duration-150 hover:opacity-90 active:opacity-80",
							onClick: () => engineRef.current?.startRun(),
							children: "Start run"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-6 grid gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Helm",
									v: "W thrusts, S brakes, A turns left, D turns right"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Wake",
									v: "Cross enemies with the trail you just drew"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Dash",
									v: "Shift slips through a hit, including your own amber"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									k: "Pulse",
									v: "Space, or a click, shatters the lace around you"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
							save,
							onVolume: (v) => engineRef.current?.setVolume(v),
							onShake: (on) => engineRef.current?.setShake(on),
							onMute: () => engineRef.current?.toggleMute()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm text-subtle tabular-nums",
							children: ["Best ", fmt(save.best)]
						})
					]
				})
			}) : null,
			phase === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
				title: "Paused",
				detail: "The wake is holding still.",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-12 w-full rounded-control bg-glass font-semibold text-ink",
					onClick: () => engineRef.current?.togglePause(),
					children: "Resume"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
					save,
					onVolume: (v) => engineRef.current?.setVolume(v),
					onShake: (on) => engineRef.current?.setShake(on),
					onMute: () => engineRef.current?.toggleMute()
				})]
			}) : null,
			phase === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
				title: "Wake closed",
				detail: `Score ${fmt(engineRef.current?.state.score ?? 0)}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: ["Best ", fmt(save.best)]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-4 h-12 w-full rounded-control bg-glass font-semibold text-ink",
					onClick: () => engineRef.current?.startRun(),
					children: "Run again"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: playing ? phase : "menu"
			})
		]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[4.5rem_1fr] gap-3 border-t border-line pt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: v })]
	});
}
function Meter({ label, barRef }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-1 flex justify-between text-xs text-subtle",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-1.5 overflow-hidden rounded-full bg-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			ref: barRef,
			className: "block h-full w-full origin-left bg-glass",
			style: { transform: "scaleX(1)" }
		})
	})] });
}
function Settings({ save, onVolume, onShake, onMute }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 flex flex-col gap-3 border-t border-line pt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-3 text-sm text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-16",
				children: "Volume"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "h-11 w-full",
				type: "range",
				min: 0,
				max: 100,
				"aria-label": "Volume",
				value: Math.round(save.volume * 100),
				onChange: (e) => onVolume(Number(e.target.value) / 100)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 flex-1 rounded-control border border-line text-sm",
				onClick: onMute,
				children: save.mute ? "Muted" : "Sound on"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 flex-1 rounded-control border border-line text-sm",
				onClick: () => onShake(!save.shake),
				children: save.shake ? "Shake on" : "Shake off"
			})]
		})]
	});
}
function Overlay({ title, detail, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex items-center justify-center bg-ink/50 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rise w-full max-w-sm rounded-panel border border-line bg-elev p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl font-semibold tracking-tight",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: detail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children
				})
			]
		})
	});
}
function TouchLayer({ onStick, onDash, onPulse }) {
	const knob = (0, import_react.useRef)(null);
	const active = (0, import_react.useRef)(-1);
	const origin = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	function place(dx, dy) {
		if (knob.current) knob.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
	}
	function release() {
		active.current = -1;
		place(0, 0);
		onStick(0, 0);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-x-0 bottom-28 z-20 flex items-end justify-between px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-auto relative size-28 touch-none rounded-full border border-line bg-ink/80",
			onPointerDown: (e) => {
				e.currentTarget.setPointerCapture(e.pointerId);
				active.current = e.pointerId;
				origin.current = {
					x: e.clientX,
					y: e.clientY
				};
			},
			onPointerMove: (e) => {
				if (active.current !== e.pointerId) return;
				let dx = e.clientX - origin.current.x;
				let dy = e.clientY - origin.current.y;
				const mag = Math.hypot(dx, dy);
				const max = 44;
				if (mag > max) {
					dx = dx / mag * max;
					dy = dy / mag * max;
				}
				place(dx, dy);
				const nx = dx / max;
				const ny = -dy / max;
				const m = Math.hypot(nx, ny);
				if (m < .2) onStick(0, 0);
				else {
					const scale = (m - .2) / .8 / m;
					onStick(nx * scale, ny * scale);
				}
			},
			onPointerUp: release,
			onPointerCancel: release,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: knob,
				className: "absolute top-1/2 left-1/2 size-11 rounded-full bg-glass",
				style: { transform: "translate(-50%, -50%)" }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-auto flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "size-14 rounded-full border border-line bg-ink/80 text-sm font-medium",
				onPointerDown: (e) => {
					e.preventDefault();
					onDash();
				},
				children: "Dash"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "size-14 rounded-full bg-glass text-sm font-semibold text-ink",
				onPointerDown: (e) => {
					e.preventDefault();
					onPulse();
				},
				children: "Pulse"
			})]
		})]
	});
}
var SplitComponent = LaceApp;
//#endregion
export { SplitComponent as component };
