//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ou14-T5i.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CBldKAdg.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CBldKAdg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CJtQTMhq.js"]
	}
} });
//#endregion
export { tsrStartManifest };
